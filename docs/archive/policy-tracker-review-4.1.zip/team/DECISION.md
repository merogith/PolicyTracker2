# Final update decision

**Decision updated after UI feedback:** review the [layered dashboard and scoring revision](../ui-scoring/README.md) alongside this implementation plan. It replaces the proposed coverage-only headline and hidden claim scores. The two-stage pipeline, evidence fixes, taxonomy scope and automatic-publication plan remain unchanged.

Review pack / presentation 4.1.0; scoring method 4.0.0; LLM pipeline/taxonomy 3.0.0 • 20 October 2026 • Prepared for a go/no-go decision; application behavior is unchanged.

## Recommendation

Keep the existing two-stage architecture and 16-domain/64-topic system. Make the handoff safer, the model inputs smaller and explicit, and the dashboard show claim counts, explicit response detail and breadth across topics. Do not add a planning agent, a scoring LLM, a mandatory judge, a graph database or a universal policy-quality index.

The numerical headline should answer **“How explicitly are responses documented across our common topics?”** Score each response with four equal checks; average distinct responses by topic and fixed topics by domain/country. Display unique claims and addressed topics beside the score. A shared source profile makes comparisons more interpretable; implementation and country priorities remain visible without hidden weights.

The latest refinement follows UN-oriented practice without adding complexity: retain country context and priorities, read climate and disaster policy through risk-informed planning, and distinguish policy intent, implementation reports, outputs and reported outcomes. Exact sources and transparent scope support comparison. The [method](../ui-scoring/METHOD.md) cites the relevant NAP, Sendai and transparency guidance. Navigation becomes country overview → domain topics → claim evidence; shared bands describe Limited / Basic / Moderate / Substantial policy detail. The scoring arithmetic, taxonomy and two LLM stages stay the same.

## Decisions proposed for approval

| Decision | Recommended default | Reason |
|---|---|---|
| Normal pipeline | Document/domain extraction → code pooling → country/domain organization → code metrics | Smallest change; preserves document and combined views |
| LLM input | Explicit templates, compiled vocabulary/schema and authorized data only | Prevents old documentation, old prompts and unrelated files entering requests |
| Scoring headline | Four-check response score, topic/domain averages, claims and topic coverage | Separates explicitness, quantity and breadth; repeatable arithmetic |
| Topic display | Claims, responses, average score, score color and comparable-change arrow | One legend from claim through country; details explain the number |
| Comparison corpus | Separate NDC-only, NDC+NAP and all-supplied views | Avoids treating different document inventories as equivalent |
| Priorities | Cited country-priority lens, without changing common scores | Water and tourism can matter differently without corrupting comparability |
| Publication | Automatic, with partial status when necessary | No human moderation or acceptance queue |
| Customization | One versioned bundle; basic settings first, advanced fields collapsed | Easy to extend without creating competing sources of truth |

## What the numbers mean

For ten common topics, six response-topic averages of 80 and four complete no-response topics produce a **48/100 domain score**, shown beside **6/10 topics addressed**. Claim counts are not additional score weights. The country uses all unique topics once, not an average of unequal domain sizes.

If inventory or qualification is incomplete, show an unavailable score and qualified observed counts. Possible bounds may appear in details. Adding a broad new response can lower an average, so a provisional response mean is not a guaranteed lower bound.

A high value means more explicit responses across the fixed topic basket in the selected corpus. It does not establish adequate ambition, implementation or outcomes. One detailed response no longer replaces the average of all distinct responses. Grouping consistency and document scope are essential to comparability.

## What must change before activation

| Priority | Change | Acceptance evidence |
|---|---|---|
| P0 | Preserve numeric meaning during quote verification; separate strict eligibility from tolerant highlighting | Minus sign, decimal, range, comparator and unit regression fixtures |
| P0 | Make search coverage and job completion code-owned | No-search, failed source and unreadable page cannot become a complete empty result |
| P0 | Wait for the contributing extraction manifest before topic pooling | A record found through another domain is included; late unrelated uploads do not block forever |
| P0 | Bound output size and split oversized tasks | Truncated output is not retried indefinitely or silently accepted |
| P0 | Preserve quotes, facts, source IDs and variants through organization | Every owned record accounted once; conflicts retained; no unrelated field borrowing |
| P0 | Replace stage maxima and legacy sums in every dashboard consumer | Same metrics, source scope and uncertainty everywhere; document history remains source-local |
| P1 | Expose the versioned configuration editor | Preview prompt/input/schema and change impact; export/restore without file/database drift |
| P1 | Measure model/context choices on representative material | Recall, attribution, false merges, contradictions, cost and latency compared using the same sources |

The current quote matcher can erase a minus sign or join a range. The current worker waits only for jobs from the same domain. These are concrete code findings, not hypothetical concerns. Their locations and remaining edge cases are recorded in reference/REVIEW-FINDINGS.md.

## Implementation sequence

1. Preserve current source and outputs; add one configuration loader and the lean wire contracts.
2. Fix retrieval/verification/budget accounting; persist sourced atomic records and coverage.
3. Add the frozen input barrier, topic pooling, conservative organization and stable ownership.
4. Add source-profile snapshots, four-check scoring, unique counts, topic coverage and documented-change comparisons.
5. Update regional, country, topic and document screens; then settings and diagnostics.
6. Run automatic release tests and representative-source evaluations; activate the new method as a versioned release.

The release evaluation is software testing, not a human review step for each country. Users upload/identify sources and configure the tool; once processing starts, it proceeds to published results or clearly labelled partial results automatically. Post-publication users can flag or hide items.

## Options deliberately deferred

| Option | Why not initially | Reconsider when |
|---|---|---|
| Extract every page with a model | More output and duplicate handling; better recall is not established | A fixed benchmark shows material gains over focused retrieval |
| Universal topic 0–100 quality score | Needs normative topic-specific indicators and weights | Team explicitly wants a separate assessment framework and can define it |
| Country-specific score weights/N/A inference | Changes denominators and can reward missing evidence | A transparent shared comparison profile is agreed, with verified applicability data |
| Multi-agent/judge pipeline | Adds cost and coordination without proven value | Error evaluation shows a targeted second interpretation materially helps |
| All optional taxonomy facets on every request | Extra fields and cognitive load | Stakeholders use those filters enough to justify extraction cost |

## What is ready, what is not

This review pack includes proposed prompts, editable vocabulary/configuration, strict wire-contract definitions, offline request examples, reference metric calculations, dashboard design, diagrams and team PDFs. Exact current application files and current prompt renders are preserved separately with hashes.

It does not activate new runtime behavior or claim measured LLM accuracy/cost savings. The code migration remains the decision this plan prepares. No API calls, live database migration or country assessment is required to review these files.

## Suggested team discussion

Review the new layered dashboard and four-check rubric; decide whether optional inclusion/group labels should be enabled initially; choose the first comparison source profile; agree the fixed representative evaluation set. These are product-design choices, not recurring manual moderation duties.
