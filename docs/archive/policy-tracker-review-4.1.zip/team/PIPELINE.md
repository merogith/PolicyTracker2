# Pipeline: simple operation, traceable evidence

19 October 2026 · Version 3.0.0 · **Review specification, not active application behavior.** The executable reference builds requests and checks data offline. It makes no LLM calls, changes no database and activates no new runtime behavior.

## The recommendation in one minute

Keep **two LLM stages**. Stage 1 reads each selected document through the existing domain questions and extracts sourced statements. Code collects those statements by their assigned topics. Stage 2 organizes related assertions across the country's documents. Code then calculates the [four-check response scores and fixed-topic averages](../ui-scoring/METHOD.md), alongside counts and topic coverage, and publishes automatically.

The first operating profile uses **NDC and NAP documents**, within the existing regional climate/disaster scope and **16 domains / 64 topics**. Additional document roles can be introduced through an explicit source-profile extension. Keeping disaster topics does not require pretending that a missing DRR document was supplied.

```mermaid
flowchart LR
  A[Selected NDC / NAP files] --> B[Code: pages, retrieval and coverage]
  B --> C[LLM 1: sourced records]
  C --> D[Code: check, retain and pool by topic]
  D --> E[LLM 2: claims, variants and relationships]
  E --> F[Code: claim scores, topic averages and counts]
  F --> G[Automatic dashboard snapshot]
```

Pooling and scoring do not call another LLM. There is no mandatory human review or validation gate before publication. Users can inspect, flag or hide published material afterward. Failed processing remains visible as incomplete, rather than becoming evidence that a policy is absent.

## Step by step

| Step | What happens | Simple example |
|---|---|---|
| 1. Select the source set | Code freezes document IDs, roles, editions/date rules and the configuration version. Historical files remain accessible separately. | The current comparison uses a selected NDC and NAP. Excluding an older edition from this view does not mean the policy was withdrawn. |
| 2. Prepare evidence | Extract/index readable pages. Retrieve bounded domain/topic query bundles and retain necessary section headings, table headers and footnotes as separately identified source units. | A target row on page 18 refers to the table header on page 17. Both units are supplied and can be cited. |
| 3. Extract records | LLM 1 returns atomic statements, taxonomy choices and exact source quotations. Facts and delivery details are populated only when supported. | “Water is a priority sector” becomes context with explicit unranked priority wording. It is not automatically a commitment. |
| 4. Check and retain | Code checks schema, known IDs, source scope, exact quotations and field provenance; assigns durable IDs; retains source-local assertions. | “10–20 ha” cannot pass as “1020 ha”; a minus sign cannot disappear. |
| 5. Pool by assigned topics | Code reconciles true duplicate discoveries and gives each record one owner through its primary topic. Relevant records owned elsewhere become read-only context. | A water record found through an agriculture question still reaches its assigned topic pool. |
| 6. Organize common claims | LLM 2 proposes groups, compatible variants and typed relationships using records and quotes. It has no PDF/web access. | Equivalent NDC/NAP targets share a claim; contextual capacity remains separate and linked. |
| 7. Check accounting and calculate | Code checks each owned record appears once, links resolve and source scope is preserved. It computes response scores, fixed-topic averages and distinct counts. | A plan's actor, timeframe and specific deliverable must belong to the same response. |
| 8. Publish automatically | Create a coherent snapshot after jobs terminate or the configured partial deadline. Later success creates a newer snapshot. | A documented response remains visible even if another document is unreadable. The unresolved work receives a separate coverage marker. |

## A multi-document example

Assume the documents state:

1. NDC: efficient irrigation will cover **100,000 ha by 2030**.
2. NAP: the comparable target is **80,000 ha by 2030**, with the same scope and conditions.
3. NAP: existing irrigation capacity is **60,000 ha**.
4. NAP: the Ministry of Agriculture will rehabilitate **30 km of canals during 2026–2030**.

The output keeps a target claim with two conflicting variants, a separate capacity claim and a separate rehabilitation response. The capacity can provide context, and the rehabilitation plan can support the target, without proving that the target was achieved. Different years or conditional pathways would not automatically be contradictions.

The combined topic can show **Delivery details documented** because the rehabilitation response identifies an actor, action timeframe and specific deliverable. The target conflict remains visible. A document-only view uses only that document's own evidence; the NDC does not inherit the NAP's delivery details. Historical views exclude later documents.

## Precisely what the LLM receives

The actual editable instructions are [extract.md](../pipeline/prompts/extract.md) and [organize.md](../pipeline/prompts/organize.md). [retag.md](../pipeline/maintenance/retag.md) is maintenance guidance, not a routine third stage. The offline builder currently implements the first two stages only.

| Input | Stage 1 | Stage 2 |
|---|---|---|
| Prompt | Extraction System instructions and User input sections | Organization System instructions and User input sections |
| Taxonomy | All 64 topic IDs with concise definitions, plus current/adjacent detail and routing | Relevant domain/topic definitions and relationship vocabulary |
| Vocabulary | Only enabled facets and required statement/fact/delivery choices | Relationship and comparability choices; record labels remain attached |
| Source data | Explicit physical-page units from one selected document | Immutable selected records, exact evidence, facts, owned/context-only status and prior identity candidates |
| Output schema | Strict raw record/evidence schema generated from active taxonomy/labels | Strict claim/variant/link proposal schema; references rather than copied facts |
| Model access | Supplied source packets only in this reference; retrieval belongs to code | No document search, web tool or directory access |

The builder reads exactly five allowlisted files per stage: that stage's prompt plus [taxonomy.json](../pipeline/taxonomy.json), [labels.json](../pipeline/labels.json), [pipeline.json](../pipeline/pipeline.json) and [llm-contracts.json](../pipeline/llm-contracts.json). It compiles the relevant pieces; it does not dump all five files into the prompt.

**No LLM reads this handbook, the team documents, preserved runtime copies, archives, example fixtures, scoring rules, dashboards, environment credentials or the entire project.** The two synthetic examples are passed explicitly by the demonstration command; ordinary request building never searches for them. Titles, filenames, URLs and source text remain data even when they contain apparent instructions.

Source-profile completeness is computed from the selected inventory and required roles. Search/processing completeness belongs to the job/source manifest. Neither is a model output. A missing required NAP remains a source-profile gap even when the supplied NDC was fully processed.

An explicitly exploratory supplied-all profile can set required roles to an empty list. This does not certify matched regional comparison. The current source manifest and cutoff remain external provenance: changing a country snapshot ID does not change an unchanged document's extraction prompt. Stage 2 receives only metadata for documents represented in that pack.

## Compact model output versus stored data

Keep model output smaller than the database model. Stage 1 returns local references, statement/type/topic choices, evidence quotes, optional facts, nullable delivery details, enabled facets, explicit priority wording and field provenance. It does **not** manufacture global claim/policy IDs, verification flags, scores or completion states.

`field_evidence` is a fixed-shape array of JSON Pointer paths and local evidence references. Code can turn it into a stored map after validating the references. Unknown values stay null or the vocabulary's not_stated value. Empty optional arrays are allowed; additional labels do not earn scoring points.

Stage 2 returns local proposed claims/variants, supplied record IDs, proposed detail associations and record-to-record relationship edges. It references immutable facts instead of copying them again. Context-only evidence can be linked without becoming a second owned record. Unmapped records remain visible in a local code-retained bucket and can be relabeled after taxonomy changes.

Code assigns persistent identities, source-page mappings, versions, budgets, automatic check states and documentation scores. It can check referential consistency; it cannot prove every semantic association merely because IDs and JSON are valid.

If organization fails or retains an unresolved record, code can publish its verified source-local assertion as a **provisional singleton assessment**. Directly evidenced responses and delivery details stay visible, with no cross-record borrowing. Mark organization incomplete; missing predicates remain unknown and common-claim counts remain provisional rather than a headline total. Later successful organization publishes a newer snapshot with identity lineage. This fallback needs no extra model or human review.

See [DATA-DICTIONARY.md](../reference/DATA-DICTIONARY.md) for raw-to-stored field mappings and the complete field options. The exact compiled schemas and resolved prompt strings are visible in [extraction-request.json](../examples/extraction-request.json) and [organization-request.json](../examples/organization-request.json). Both are explicitly synthetic previews, not actual country runs.

## Parallel work, ordering and limits

Use an initial configurable maximum of **four concurrent country work units**. Document/domain extraction units run in parallel. Freeze the selected source/configuration manifest and wait until **all** Stage 1 units in that manifest are terminal—or the partial deadline is reached—before pooling. Then organize independent home-domain packs in parallel.

This barrier must include all contributing extraction domains. Waiting only for the same domain question is insufficient because another question can discover a record assigned to this topic. Coalesce uploads into one update rather than repeatedly regenerating the same group after every arrival. Later unrelated uploads belong to a newer manifest.

| Initial setting | Target | Hard guard / behavior |
|---|---|---|
| Stage 1 supplied source text | 8,000 estimated tokens | 18,000 estimated source tokens; split larger packets |
| Stage 1 output reservation | 6,000 tokens | On truncation, split source units; do not resend an unchanged oversized task |
| Stage 2 record/context input | 12,000 estimated tokens | 24,000 estimated record/context tokens; partition and reconcile boundaries |
| Stage 2 output reservation | 6,000 tokens | On truncation, split owned-record batches and preserve membership accounting |
| Retrieval per document/domain unit | Up to 3 search calls, up to 20 results each | Log queries, returned source units, omissions and unreadable material |
| Interactive publication deadline | 60 minutes | Publish explicit partial state; this is not a guaranteed completion time |

These are **unmeasured initial operating hypotheses**, not promised efficiency or accuracy. The offline builder uses characters divided by three as a conservative working estimate and rejects requests above the configured guard. It never silently drops input. This estimate is not a tokenizer: production must check the selected model's actual tokenization/context rules, including instructions, schemas, source/context, output/reasoning and safety margin.

Source/table context can be carried into adjacent partitions without assigning it duplicate record ownership. Boundary identity checks remain within Stage 2. A chain of similarities must not merge incompatible endpoints: A resembles B and B resembles C does not establish that A and C describe the same target.

## Where efficiency comes from

Two stages do not require two different models. Start with the same validated model for both; test a cheaper organization model as an optional override only if it preserves grouping, contradiction and source-attribution quality. Organization can be harder than extraction, so a cheaper default is not automatically safer or more efficient after repairs.

- Reuse extraction for unchanged document bytes and semantic configuration. Reorganize only affected topic groups and dependency neighbors.
- Keep all topic IDs available, but avoid repeatedly sending unrelated full operator documents or disabled vocabulary modules.
- Skip an LLM call when a completed code retrieval plan returns no source units; record the bounded-search outcome and limitations in code. Skip empty organization packs. Do not infer whole-document absence from an empty extraction response.
- Return record/evidence references from Stage 2 instead of repeating large factual objects.
- Recalculate scoring edits from retained facts under a versioned rubric. A display-name edit needs no model call. A genuine topic expansion needs new source search, not only retagging.
- Use one persisted country-update cost allowance across search, retries, repairs, OCR and overflow. Keep uncertain spend reserved; report storage separately. Do not multiply independent SDK and worker retry budgets.

Extraction cache keys use document/source-unit content and semantic prompt/schema/model settings. Organization keys use owned/context record content, relevant document metadata and identity candidates. Country snapshot IDs do not invalidate either by themselves. A source cutoff that actually changes selected evidence changes the dependent pack, as it should.

Retain the 16-domain retrieval approach initially. Compare it against code-deduplicated retrieval packets and, later, section-first extraction on the same representative sources. A section-first approach may reduce repeated context but may also lose targeted topic coverage and produce larger outputs. No default change is justified by call count alone.

## Concrete source-code findings to resolve during integration

These references describe the current application, not fixes already activated by this review package.

| Existing behavior | Planned correction |
|---|---|
| [verify.ts:23](D:/Policy-tracker-main/src/lib/analysis/verify.ts:23) removes dashes/minus signs; [verify.ts:43](D:/Policy-tracker-main/src/lib/analysis/verify.ts:43) also removes whitespace in a matching path. “10–20” can therefore match “1020”, and a negative figure can match a positive figure. | Strict eligibility checks preserve signs, ranges and comparators. Tolerant highlighting is a separate operation. The offline reference tests reject both examples. |
| [synthesise.ts:15](D:/Policy-tracker-main/src/lib/analysis/synthesise.ts:15) strips source quotes/topic tags; [synthesise.ts:49](D:/Policy-tracker-main/src/lib/analysis/synthesise.ts:49) selects the same extraction-domain answers. | Pool by assigned topics; retain evidence and qualifiers in the organization input. |
| [handlers.ts:46](D:/Policy-tracker-main/src/worker/handlers.ts:46) waits for extraction jobs in the same domain. | Freeze the full selected input manifest and account for all contributing Stage 1 units before pooling. |
| [call.ts:28](D:/Policy-tracker-main/src/lib/analysis/call.ts:28) retries a failed/truncated task; [openai.ts:243](D:/Policy-tracker-main/src/lib/openai.ts:243) defaults to a large output allowance. | Explicit output reservation and deterministic splitting; never repeatedly retry the same oversized payload. |
| [openai.ts:251](D:/Policy-tracker-main/src/lib/openai.ts:251) limits search results, not total search calls; [cost.ts:41](D:/Policy-tracker-main/src/lib/cost.ts:41) supplies an estimated cap. | Code-owned query accounting and one persisted runtime update allowance. |
| [schemas.ts:20](D:/Policy-tracker-main/src/lib/analysis/schemas.ts:20) has only the older limited figure contract; source-linked delivery checks are absent. | Implement the reviewed raw schemas and explicit code-owned normalization adapter before activating the four-check calculator. |

## Run the reference locally

From the repository root, using Node 24 or later:

```text
node docs/review/reference/build-inputs.mjs --write-examples
node docs/review/reference/input-contract.test.mjs
```

The first command regenerates only the two synthetic request previews. Each includes resolved prompt text, a compiled strict schema, exact input-file SHA-256 hashes, selected source IDs and clearly labeled character-based estimates. A production dispatcher would add the selected supported model; the offline builder does not read credentials or call a provider.

The tests exercise allowlist rejection, unknown IDs, prompt-placeholder handling, untrusted source instructions, source-scope isolation, missing required roles, full-catalogue routing, context/ownership separation, exact record accounting, field provenance, cropped numeric signs/ranges/comparators, as-stated units/periods, stable incremental requests and overlarge input failure. The numeric-span guard recognizes common numeric and English comparator forms; it is not a universal multilingual quantity parser. These tests do not measure real-document extraction accuracy or prove semantic entailment or prompt-injection resistance of a model.

Before runtime activation, integrate the schemas, storage adapter, scheduler barrier and budget ledger; evaluate representative readable, scanned, tabular and multilingual NDC/NAP documents. Keep the residual limitations explicit: retrieval can miss evidence, table/OCR interpretation can fail, and a correct quotation can still be misclassified. These development checks do not create a country-by-country human approval queue.
