# Start here: policy tracker final review

**Version 3.0.0 · 19 October 2026 · proposed update, not active runtime.**

The recommendation is a lean two-stage pipeline with explicit inputs, preserved sources and automatic publication. The dashboard compares documented response coverage, keeps delivery detail and reported implementation separate, and lets users reach exact evidence in one click.

## Read in this order

| Audience / question | Open |
|---|---|
| Decision maker: what are we approving? | [Decision and update plan](team/DECISION.md) |
| Whole team: how does information move? | [Pipeline and LLM inputs](team/PIPELINE.md) |
| Analysts: what do numbers, colors and arrows mean? | [Scoring method](team/SCORING.md) |
| Product team: what appears on each screen? | [Dashboard priorities](team/DASHBOARDS.md) |
| Everyone reviewing categories | [Full taxonomy and label catalogue](team/TAXONOMY.md) |
| Engineer: what could fail? | [Deep review findings](reference/REVIEW-FINDINGS.md) |
| Engineer: what are the fields? | [Data dictionary](reference/DATA-DICTIONARY.md), [wire contracts](pipeline/llm-contracts.json) |
| Exact current implementation, safely preserved | [Preserved source guide](preserved/README.md) |
| Tests and delivery boundary | [Verification](reference/VERIFICATION.md) |

## The method in one minute

For sharing, open the [four-page decision PDF](pdf/policy-tracker-v3-decision-plan.pdf), [team handbook](pdf/policy-tracker-v3-team-handbook.pdf), [taxonomy and fields](pdf/policy-tracker-v3-taxonomy-and-fields.pdf) and [current/proposed prompt sourcebook](pdf/policy-tracker-v3-prompt-sourcebook.pdf). The longer books are reference material; the decision PDF is the first read.

Explore the [local dashboard mockup](visuals/dashboard-preview.html), [simple process](visuals/process-simple.svg) and [engineering flow](visuals/process-technical.svg). Both diagrams can be edited in [pipeline.drawio](visuals/pipeline.drawio). The mockup is synthetic and has no live backend.

1. Register each NAP/NDC and prepare searchable page text with source identity and readability limitations.
2. **LLM 1** extracts atomic statements per document/domain, with quotes, topics and explicit factual detail.
3. Code waits for the frozen input manifest, verifies evidence and pools records by assigned topic across documents.
4. **LLM 2** organizes conservative common claims and links, preserving conflicting values and supporting context.
5. Code computes topic bands and country/domain coverage percentages over a fixed profile.
6. Publish automatically, including incomplete-state labels when needed. Users may flag or hide afterward.

Independent extraction jobs run in bounded parallel. Organization starts after the contributing input snapshot is frozen, then independent packs can run in parallel. These are two logical model stages, not exactly two API requests. Pooling and scoring do not call an LLM.

## Numbers without a misleading composite

**6 of 10 topics have responses = 60% response coverage.** If two topics have Who + When + specific What for one coherent response, delivery-detail coverage is 20%. A reported implementation statement is a separate signal. Missing work produces bounds, such as 60–80%, rather than a false exact score.

The four topic bands remain **No evidence found, Context documented, Policy response documented, Delivery details documented**. They describe the selected source material. They do not measure policy adequacy or climate outcomes. Arrows show comparable documentation changes; backfills and method changes get a refresh marker instead.

Country priorities are highlighted only when explicitly sourced. They can change sorting and focus but never silently reweight the common comparison. NDC-only, NDC+NAP and all-supplied views are distinct source scopes.

## One small structure

```text
review/
  README.md                    entry point
  team/                        five discussion documents
  pipeline/                    proposed machine configuration and contracts
    prompts/                   two normal LLM prompts
    maintenance/               occasional retag prompt
  examples/                    synthetic data and rendered requests; never auto-loaded
  reference/                   offline builders, checks, field dictionary and audit
  visuals/                     editable diagrams and dashboard example
  pdf/                         generated presentation copies
  preserved/                   frozen current source; never model input
```

Only explicit paths in the pipeline manifest can contribute to a model request. The model never browses this folder or receives all Markdown. Team guides, archives, scoring rules, test fixtures, previous scores and unrelated sources are not prompt context. A future coding assistant starts here, then follows the current manifest; it does not choose the newest-looking file by filename.

## Files humans can change later

| Change | Authoritative proposed file | Automatic effect |
|---|---|---|
| Domains/topics/routing | [taxonomy.json](pipeline/taxonomy.json) | Retag affected records; search sources if scope expands |
| Label choices and optional modules | [labels.json](pipeline/labels.json) | Re-extract/retag affected fields; do not invent old missing labels |
| Extraction behavior | [extract.md](pipeline/prompts/extract.md) | New method version and affected extraction |
| Grouping behavior | [organize.md](pipeline/prompts/organize.md) | Reuse source records, regroup affected packs |
| Limits/models/concurrency | [pipeline.json](pipeline/pipeline.json) | New processing configuration; no mid-run change |
| Metrics/profiles/arrows | [scoring.json](pipeline/scoring.json) | Recompute from stored supported fields; preserve prior versions |
| Model output shape | [llm-contracts.json](pipeline/llm-contracts.json) | Validate adapters and fixtures together |

UI settings must edit/export the same immutable bundle. Saving a display-only edit requires no model call. Source statements, raw evidence and old snapshots remain recoverable.

## Preserve versus propose

The [application archive](preserved/application-before-update.zip) contains exact pre-update code/configuration with a [SHA-256 manifest](preserved/application-manifest.json). The [current prompt/reference archive](preserved/current-runtime.zip) includes real prompt-builder code and illustrative renders produced by it. Live database settings and credentials are not included. The earlier review pack is preserved separately under docs/archive.

The files in pipeline/ are proposed replacements. The offline examples demonstrate their assembly and metric rules; they do not establish live LLM accuracy or production cost. Application integration remains the work described in the decision plan.

The full package is also available as `docs/policy-tracker-final-review.zip`. `PACK-MANIFEST.json` lists every delivered file and hash; `pipeline/bundle.json` identifies the proposed configuration and reference contracts. Only each stage's explicit input allowlist enters request assembly, not every file in either manifest.
