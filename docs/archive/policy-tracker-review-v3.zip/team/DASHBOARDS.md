# Dashboard review: what users see and do

**Review specification 3.0.0 — not active in the application.** The dashboard describes the supplied climate and disaster policy documentation. It does not rate actual resilience, policy effectiveness or the adequacy of ambition.

The main path is **Region → Country → Domain → Topic → Claim → Source**. Keep that path visible in breadcrumbs. A document selector changes the evidence scope without creating another navigation system.

## One visual language

| Visual element | Meaning |
|---|---|
| **Response coverage %** | Share of the fixed topics with an attributable policy response documented. |
| **Delivery-detail coverage %** | Share of the same fixed topics with at least one response specifying a responsible/implementing organization, action timeframe and verifiable deliverable. |
| **Implementation reported** — secondary | Topics with source-reported implementation or delivered output under the evidence rules. This is not verified success or target achievement. |
| Four topic-band colors | No evidence found; Context documented; Policy response documented; Delivery details documented. |
| Hatch and status text | Incomplete processing or unresolved qualification. Unknown does not become zero. |
| Conflict / condition / priority badges | Different source properties, shown separately from the bands. |
| Change arrow | A documentation change between comparable complete snapshots, with evidence behind it. |

Use at most **three headline numbers**, led by the first two. Prefer percentages with a visible fixed denominator and an explanation on selection. Band distributions explain those numbers. Raw finding counts, quote-match rates and model costs belong in evidence or run details.

Topic bands use one ordered neutral-to-blue palette with readable labels. Domain icons may use distinctive accent colors. **Do not color an entire domain or country by its maximum topic band, average band code or mean implementation stage.** Unavailable has a neutral patterned treatment outside the four-band scale.

Country percentages count each of the **64 unique topics once**. They are not means of the 16 domain percentages: domains have different numbers of home topics. Domain percentages use their fixed home-topic subsets. Four bands are categories, not numerical weights.

For each coverage measure, count **P** topics already established, **A** topics where qualifying evidence is absent after resolution, and **U** unresolved topics; **N = P + A + U**. Show `100 × P/N` to `100 × (P+U)/N`; use a single percentage when U is zero. For example, six established, two absent and two unresolved topics give **60–80%**. Apply the rule separately to response, delivery details and implementation reported; their unresolved sets may differ. Processing completeness remains a separate status, not `N−U`. Show supplied-job completion and missing required document roles separately. Effective completeness requires both: a missing required NAP keeps unproved coverage unknown even when every supplied file finished.

Implementation reported requires an assertion of the identified response being underway or an output delivered. It does not require the topic's delivery-detail band, and the delivery-detail band does not establish implementation. A planned project can specify delivery very clearly.

## 1. Regional overview — first priority

**First look:** show the region, selected countries, as-of date, comparison profile and source eligibility before the matrix. The default profile must name its document roles: for example, **NDC only** or **NDC + NAP** with the same edition/date selection rule for every country. All-supplied-document exploration remains clearly labelled exploratory.

The country × domain matrix displays response coverage as the primary number. A small distribution below it shows how the topics fall across the bands; delivery-detail coverage can appear on hover/selection or in a metric switch. Incomplete cells display ranges rather than manufactured single values. Do not try to fit every badge and metric into every cell.

**Drill-down:** selecting a domain opens a country × topic matrix. Topic cells use the four bands directly. Selecting one opens the same topic drawer used elsewhere, with the country and source scope retained.

**Actions:** select countries, domain, source profile or as-of date; compare up to a few countries side by side; export a table with band names, coverage and source references. Default order is alphabetical or the user's chosen order, not a national quality ranking.

**Example:** “Water: 4 of 6 home topics document responses” can appear beside “2 of 6 specify delivery.” The comparison is meaningful only within the same Water topic basket and source profile. A country with an NDC and NAP is not silently compared with another country represented by its NDC alone.

## 2. Country overview — first priority

**First look:** a short source header shows included NDC/NAP editions, as-of date, processing status and comparison eligibility. Then show the two headline coverage numbers; implementation reported is a smaller secondary indicator. Keep all 16 domain tiles available.

Each domain tile contains its name, home-topic denominator, response coverage and a small band distribution. Delivery-detail coverage may be the second number. Move detailed counts, stage distributions and technical diagnostics into the selected domain. One well-documented project must not make the whole tile look complete.

**Drill-down:** selecting a domain lists its home topics with band, one-sentence explanation and any conflict/incomplete badge. Related topics from another domain appear in a separate section: **“Also relevant — counted under another domain.”** AGR-01 irrigation can be visible under Water while remaining counted under Agriculture.

**Actions:** open topics, select documents, compare snapshots, add documents and export evidence. Use stable navigation—**Overview, Topics, Documents**—rather than adding a tab for every uploaded document. Put any generated brief inside Overview; it must not become another competing result system.

Remove the default radial chart of finding counts. Finding volume depends on extraction and splitting choices; a larger wedge can look like stronger policy when it merely means more text.

## 3. Topic drawer and claim detail — first priority

**First look:** topic name and code, band, a short reason, and the source scope. For band 3, use “At least one response has delivery details,” not “Topic fully covered.” Composite topics may contain several policy aspects.

Show these sections in order:

1. **Documented responses.** Common claims, their statement types and the three delivery checks: who, when, what specifically. Each check opens the exact source evidence for that response, variant and selected topic. A secondary topic only receives its own source-qualified response/details; it never inherits all checks from a tag.
2. **Concerns and context.** Risks, needs, baselines and reported effects. Keep them visible without implying implementation.
3. **Disagreements and related evidence.** Target variants together; capacity and supporting actions as separate linked claims. Explain the relationship in one sentence.
4. **Sources and limitations.** Document/page links, searched scope, incomplete work and configuration version.

**Actions:** open a quotation on its physical page, compare documents, inspect history, flag a claim, hide/reveal it and export. Technical field provenance belongs under “Method details.” Ordinary users should not need to understand prompt variables or schema names.

**Example:** an NDC's 100,000-hectare target and a comparable NAP's 80,000-hectare target remain conflicting variants. A NAP's 60,000 hectares of existing capacity remains context. A separate ministry plan for 30 km of canal rehabilitation can establish the topic's delivery-detail band without filling the target's missing actor or proving the target has been achieved.

## 4. Priority and evidence-gap lenses

Provide three plain filters on the topic/evidence view:

| Lens | What qualifies | What the user can conclude |
|---|---|---|
| **Explicit document priorities** | Source text explicitly identifies a priority; display that wording and its quotation. | The source prioritizes this concern, need or response. |
| **Needs with no response found** | A sourced concern/need and no qualifying response in the current assessed scope. Incomplete work is labelled. | A documentation gap worth investigating, not proof that no action exists. |
| **Conflicting statements** | Source-qualified comparable assertions disagree and lack an evidenced resolution. | The documents need closer reading; the tool does not choose a winner. |

Priorities are **not** inferred from repetition, severe hazards, document length or model judgement. The optional `priority_evidence` field is source wording, not an importance score. “Drought is a priority risk” remains a concern; it does not become a response.

“Most actionable” should mean these transparent evidence conditions, not an opaque ranking. Users may filter or pin relevant domains, but priority lenses neither drop topics from the benchmark nor change weights. A missing response to a stated need and an analyst's assumed need are different things; show only the former as a documented gap.

## 5. Documents and source comparison

**First look:** a document table with title, role, edition/family, included scope, readable/unreadable material and processing state. Select a document from a picker. The selected view uses only that document's evidence and the same topic taxonomy.

**Drill-down:** a claim-by-document table aligns assertions while retaining each target value, baseline, period, condition and source-local implementation stage. Open the source page beside the table. Use “Not repeated” for an omission; a later document does not automatically withdraw or supersede an earlier undertaking.

**Actions:** choose two documents, inspect differences, download the source, add a new edition and export the comparison. Retry failed processing from diagnostics. Avoid a prominent “Re-run everything” as the ordinary refresh action; incremental processing should reuse unchanged work.

NDC and NAP are the initial document roles. Additional roles require an explicit profile update and the same rules across the comparison group. Their later availability must not silently redefine a previous benchmark. All-supplied views remain useful exploration, even when country source profiles differ.

## 6. History and arrows

Arrows describe **documentation change**, not climate progress. A comparable change requires the same topic and source-role profile, method/rubric, date convention, complete source profiles, complete relevant processing and exact metric values. Compare genuine editions in the same document families. Record the before/after snapshot IDs.

- A directional arrow appears only when the comparison establishes a direction under the metric's change rule. It opens the exact changed topics and sources.
- A source backfill or methodology change uses a **refresh symbol** and explanation, not an improvement/regression arrow.
- Incomplete or incomparable snapshots show “Change not comparable” or “Pending,” not a flat arrow.
- Individual claim histories can show a source-supported change from planned to underway. That does not create a domain-wide implementation trend.

The newest NAP versus all earlier documents is not a valid generic progress comparison. A newly uploaded document may reveal older evidence; its upload date must not become the date of policy change.

## 7. Settings — one editor for the actual bundle

| Area | Default controls | Advanced detail |
|---|---|---|
| Taxonomy & labels | Domain/topic definition, home, display placements, routing; enabled label modules | Stable IDs, lineage, all enum choices, source-explicit priority field |
| Prompts | Extract and organize templates | Maintenance prompt, resolved message/schema preview, hashes |
| Documentation bands | Readable qualification rules and coverage definitions | Versioned changes and regression examples |
| Processing | Document roles, model roles, budgets and automatic retry limits | Retrieval settings, cache invalidation and publication deadlines |

Core labels are purpose, hazards, geographic scope and policy instruments. Themes and affected groups are an optional context module, disabled initially; specialist risk labels are also disabled. The quotes and source assertions remain available. Enabling a module later requires the appropriate automatic retagging or source extraction before its structured coverage can be claimed.

Every edit shows its impact before the user saves a new bundle: display-only; relabel; reorganize; re-extract; or recompute. Keep topic IDs stable when changing display order or an organizational home; semantic splits/merges require explicit lineage. Never use placement order as an implicit scoring-home editor.

This is configuration control, not a moderation screen. Normal outputs publish automatically after bounded machine checks. A saved method change does not turn current results into reviewed or approved policy facts.

## 8. Unmapped evidence and diagnostics

Provide an **Unmapped evidence** entry with a visible count and searchable source-linked records. Null topic assignment means the subject did not fit; it is not an “Other” domain. A record's statement type stays intact. `statement_type: other` is a separate fallback for assertion type and can occur with a known topic.

Retain relevant cross-cutting climate/disaster concepts even if they lack a topic. Do not auto-add topics from them. Exclude unrelated general development material from the climate/disaster scope. Users can inspect unmapped evidence after publication and later change the taxonomy; there is no review queue holding the dashboard back.

An Activity panel contains costs, actual retrieval/page counts, source-check diagnostics, attempts and failures. Label quote checks as **source matching**, not factual validation. “Readable pages,” “pages retrieved” and “pages cited” are separate quantities.

If organization fails or remains partial, show verified source records as **Provisional individual claims**. Their own documented response/details remain usable; the system never assembles missing details across these provisional records. Mark organization incomplete, preserve uncertainty for missing coverage, and label any common-claim count provisional rather than displaying it as a headline number. Sources remain accessible without a review queue. A later completed run replaces the provisional view in a new snapshot with traceable lineage.

## Minimum implementation

Build the regional matrix, country/domain tiles, topic drawer, document comparison, settings and visible unmapped evidence first. Reuse the same evidence drawer across every screen. Support keyboard navigation, meaningful text beside colors, clear incomplete patterns and exports containing evidence IDs.

Post-publication flags/hiding remain recoverable overlays. Hiding affects presentation by default. An explicit analytical exclusion creates a separately labelled adjusted view, leaving the standard regional comparison reproducible. There is no mandatory human approval before publication.
