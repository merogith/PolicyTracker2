# Scoring review v3: coverage numbers with clear topic detail

**Version 3.0.0 · review_not_active.** This is an editable recommendation and executable reference specification. It is not the running application's scoring system. Rules are in [scoring.json](../pipeline/scoring.json).

## The recommendation in one minute

Use **two main percentages**, supported by topic colors and evidence. Keep implementation reporting separate.

| Measure | Question | Example in a ten-topic domain |
|---|---|---|
| Response coverage | How many common topics document a policy response? | 6/10 = **60%** |
| Delivery-detail coverage | How many document Who + When + a specific What for at least one coherent response? | 2/10 = **20%** |
| Implementation reported, secondary | How many explicitly report an identified response underway or delivered? | 1/10 = **10%** |

Do not blend these percentages. The first describes breadth, the second specification, and the third reporting. None measures adequate ambition, actual effectiveness, resilience or national effort. A detailed plan is not implementation; an implementation report need not contain all three delivery details.

At country level count **unique common topics**, not domain averages: “32/64 topics document a response — 50% coverage.” This is a documentation inventory statistic, not a national policy-quality score. There is no headline claim score.

## 1. Keep four topic colors

| Code | Exact label | Meaning |
|---|---|---|
| 0 | No evidence found | Complete processing of the defined usable-source scope found no qualifying topic evidence |
| 1 | Context documented | Concern, context, projection, reported effect or unadopted proposal, without an attributable policy response |
| 2 | Policy response documented | At least one attributable commitment, planned action, implementation assertion or delivered output |
| 3 | Delivery details documented | At least one coherent response has accountable actor, action timeframe and a specific verifiable deliverable |
| null | Unavailable | No qualifying evidence is available and processing is incomplete |

The code is an ordered category, not a quantity. Do not map the codes to 0/33/67/100 or average them. Topic colors use this legend. Domain/country percentages use neutral bars and exact counts, without inventing additional good/bad thresholds.

**A limitation to make visible:** one well-specified project can establish topic band 3. It does not prove complete policy coverage. Show response count, detail-ready response count and conflicts beside the topic. A detail drawer can show “2 of 3 delivery details documented” for a selected response, but this is not a new topic rating.

## 2. Calculate delivery details from three checks

| Check | Qualifies | Does not qualify |
|---|---|---|
| Who? | A named responsible or implementing organization | Funder, consulted body, supporting organization or merely mentioned actor alone |
| When? | An action period, delivery deadline or dated milestone | Publication date or unrelated observation year alone |
| What specifically? | A quantified output, identified asset, named legal instrument or identifiable milestone | “Improve resilience” or generic “rehabilitate canals” |

All three must refer to **the same coherent response**. “The Agriculture Ministry will rehabilitate 30 km of canals by 2030” qualifies. “The ministry will rehabilitate canals by 2030” lacks a sufficiently specific deliverable.

A qualitative deliverable can qualify: “Adopt the National Drought Management Regulation” does not need an invented quantity. Conditional commitments count as responses; show the condition separately. Advice and unadopted recommendations remain proposals, even when detailed.

Compatible documents can supply different details of the same identified response. A separate supporting project cannot donate its actor, deadline or output. The model extracts the facts; code applies the rubric. No LLM scoring call is needed.

Secondary-topic credit also needs direct evidence for each predicate. A topic tag alone cannot inherit the primary topic's response, delivery or implementation status. The reference adapter supplies explicit per-topic projections when a claim serves multiple topics.

## 3. Worked irrigation example

All data in [water.json](../examples/water.json) are invented for demonstration. The combined example is a `supplied_all` exploratory inventory containing both NAP editions, not the matched current NDC/NAP corpus.

| Source assertion | Interpretation |
|---|---|
| NDC: 100,000 ha of efficient irrigation by 2030 | Policy response, but no accountable actor stated |
| NAP: comparable target of 80,000 ha by 2030 | Conflicting target variant; retain both values |
| NAP: existing network served 60,000 ha in 2024 | Separate context; not 60% achievement |
| NAP: ministry will rehabilitate 30 km of canals during 2026–2030 | Separate planned response with delivery details |

The combined topic is **Delivery details documented**, because the canal action qualifies. Its target claim remains unresolved and cannot borrow the canal project's actor. No implementation is reported.

In this deliberately tiny **one-topic example profile**, response coverage is 1/1 = 100%, delivery-detail coverage is 1/1 = 100%, and implementation reporting is 0/1 = 0%. This means that the one checked topic contains those kinds of documentation; it does not mean perfect irrigation policy. The real regional profile has its full fixed topic denominator.

The NDC-only view stays band 2; the 2024 NAP is band 1; the 2026 NAP is band 3. Document evidence and stages never leak backward into earlier editions. The [normalized input](../examples/water-score-input.json), [calculated output](../examples/water-score-output.json) and [reproducible checker](../reference/check-water.mjs) make the calculation inspectable.

## 4. Treat ambiguity separately for each measure

Each coherent claim variant yields three yes/no facts: response present, delivery details present, implementation reported. If variants disagree about a fact, preserve possible outcomes.

- Claim lower: every coherent alternative qualifies.
- Claim upper: at least one alternative qualifies.
- Topic lower: at least one claim definitely qualifies.
- Topic upper: at least one claim might qualify, or required processing is incomplete.

For each measure separately, count:

- **P:** topics where the fact is demonstrated.
- **A:** topics where complete eligible processing establishes it was not found.
- **U:** topics where it remains undetermined.
- **N = P + A + U:** the fixed common denominator.

Coverage is **100 × P/N** when U = 0. Otherwise show **100 × P/N to 100 × (P+U)/N**.

Example: six responding topics, two complete topics without a response, and two unknown topics give **60–80%**, not 75% after silently dropping unknowns. Processing completeness appears separately: if those eight determinate topics were all processed, it is 8/10. P+A is not automatically the processing count.

An established response remains positive if another source fails. Delivery details and implementation can still be unknown. Thus response coverage can be exact while the corpus is incomplete; this does not make the snapshot eligible for a complete comparison.

A conflict over 80,000 versus 100,000 hectares does not automatically change any predicate. A conflict over whether a measure is only proposed or actually undertaken creates response uncertainty. Planned versus underway alternatives create implementation-report uncertainty while response coverage may remain exact. Never resolve disagreement by taking the most favorable alternative.

## 5. Preserve implementation and history

Use source statement types for reported stages: Commitment, Planned, Underway, Delivered. Context and projections have no implementation stage. A reported outcome alone does not prove a policy caused it.

The secondary implementation metric counts explicit `implementation_underway` or `output_delivered` assertions. It does not require band 3, and band 3 does not establish it. This is **implementation reporting in the selected corpus**, not a measurement of actual achievement.

Alternative variants in a current assessment are coherent competing interpretations, not an unfiltered timeline. Historical assertions remain in history; explicit update lineage determines which assertions belong in a current comparison. Do not use a historical maximum stage as current status. A newer source edition alone does not prove that an older policy has been withdrawn.

## 6. Compare the same documentary scope

The source profiles are editable, versioned definitions inside `scoring.comparison.source_profiles`:

| Profile | Source selection | Use |
|---|---|---|
| `supplied_all` | All explicitly selected supplied documents | Exploratory inventory; no comparable trend arrow |
| `ndc_only` | Latest eligible NDC edition in the agreed family as of the cutoff | Matched NDC-documentation comparison |
| `ndc_nap` | Latest eligible edition for each required NDC and NAP role/family as of the cutoff | Matched NDC/NAP-documentation comparison |

A profile chooses the comparison corpus; **it does not establish policy supersession or withdrawal**. Historical editions remain accessible outside the selected current corpus. Carry-forward of an older assertion needs explicit supporting evidence and provenance. It is not silently counted forever.

Missing a required document role means `source_profile_complete=false`. The reference calculator requires `scope.source_profile_complete` explicitly. Input topic `processing_complete` records whether the supplied jobs finished; the output's effective `processing_complete` requires **both** those jobs and the required source profile to be complete. `job_processing_complete` and `job_processed_topics` preserve technical-job success separately. With a missing required NAP, an empty successful NDC search remains unavailable/unknown, not zero. Positive evidence is retained. Never automatically substitute NDC material for a missing NAP. A functional equivalent needs an explicit versioned rule applied consistently.

Store exact source IDs, roles, family IDs, edition dates, cutoff date and ingestion timestamps. A source's publication/edition date is different from when it was uploaded. Late uploads can improve the inventory without representing a new policy.

The existing 64-topic profile is a common inventory, **not 64 universal national policy obligations**. DRR topics absent from an NDC/NAP corpus mean not found there; they do not establish weak national disaster policy. A DRR-specific comparison needs a shared profile including appropriate disaster-policy sources. Implementation comparison may also need progress-report sources because planning documents are not comprehensive implementation reports.

## 7. Country priorities and fair regional interpretation

Country A may explicitly prioritize drought and water management; Country B may emphasize resilient tourism. Highlight these stated priorities with citations. They can sort or filter the dashboard, but do not silently change common topic weights or denominators.

The same water coverage percentage means the same amount of **topic presence in the matched documents**. It does not mean equal ambition, urgency or effort in those different contexts. Do not penalize a country for failing to discuss a subject simply because another country calls it a priority.

Do not infer N/A from silence or simple geography. Landlocked countries can have fisheries; inland countries can have flood-protection policy; countries without glaciers can depend on transboundary mountain water. A future narrower common regional core is a configurable shared profile, not a per-country self-weighted score. [UNFCCC's NAP guidance](https://unfccc.int/national-adaptation-plans) emphasizes country-driven, non-prescriptive planning; our priority lens preserves that context alongside shared documentary comparisons.

At national level count each common topic once. If a small domain has 2/2 response topics and a large domain has 0/8, national inventory coverage is **2/10 = 20%**, not the unweighted domain average of 50%. No country quality composite or z-score is introduced.

### Regional averages and standard deviations

The most useful regional topic statistic is **prevalence**, not an average band: “7 of 10 comparable countries document a water-supply response.” Calculate response and delivery-detail prevalence separately, with an unresolved range when needed. Show how many countries satisfy the source profile and how many are excluded or incomplete.

For a domain, an optional distribution of country coverage percentages can show country dots and the cohort median. Use only the same topic basket, source-role/date rules and method. State the cohort and denominator; do not silently exclude countries to improve an average. If the cohort is small, the individual dots are more informative than a distribution summary.

A mean and standard deviation of **coverage percentages** can be an advanced descriptive export for complete comparable cohorts. They describe dispersion of documentation coverage, not effort. Do not calculate them from ordinal band codes, assign arbitrary midpoint scores to unknown intervals, or turn them into a z-score country ranking. Standardizing against a weakly documented region can make a modest document look excellent while concealing the absolute gaps. Keep these statistics out of the initial headline and retain absolute percentages as the shared reference.

## 8. Use arrows only for comparable documentation changes

A 60% → 70% change is **+10 percentage points of documentation coverage**. It is not a 10-point improvement in climate resilience or proof of implementation progress.

An arrow requires the same country, frozen extraction/method signature, taxonomy and scoring versions, unique topic homes/profile, source-role/family coverage and date rule. Both snapshots must be recomputed on that same basis, have complete required sources and topic processing, and have an exact value for the chosen measure.

| Event | Default display |
|---|---|
| Newer eligible edition of the same source family, after the old cutoff, on the same complete basis | Neutral up/down/unchanged documentation arrow and percentage-point difference |
| Ordinary upload, backfill of an older source, source removal or recalculation | Refresh annotation; no progress arrow |
| Method or topic/source profile change | New/recomputed baseline; no direct arrow |
| Partial processing or unresolved qualification | Arrow unavailable; no point delta |
| Evidence omitted in a later edition | “Not restated in current corpus”; no inferred withdrawal |
| Explicit withdrawal or supersession | Preserve source-backed annotation and lineage |

For specialists, an optional possible difference is **[new lower − old upper, new upper − old lower]**. This is an uncertainty range, not a statistical confidence interval. Default UI still suppresses point arrows for partial snapshots.

Use neutral direction icons for both increases and decreases. Keep four-band topic colors separate from these changes. See [DASHBOARDS.md](DASHBOARDS.md) for matching screens.

Official SDG trend assessments concern indicator trajectories toward targets. The visual clarity is useful here, but this documentary tracker uses a different construct and must not call coverage “on track” or “target achieved.” [UNSD technical note](https://unstats.un.org/sdgs/files/report/2025/Technical_Note_for_Progress_Assessment_2025.pdf).

## 9. Options and simple SWOT

| Option | Strength | Weakness | Opportunity | Threat |
|---|---|---|---|---|
| **A. Separate coverage percentages + four topic bands — recommended** | Literal counts; easy to reproduce | No smooth topic-quality number | Clear regional gaps and evidence drill-down | Users may overread coverage as adequacy unless labels stay explicit |
| B. Topic documentation-checklist percentage | More granular-looking topic score | Weights are design choices; one project can satisfy the whole checklist | Useful later if fixed topic-specific checks are agreed | False precision and maintenance burden |
| C. Percentage of extracted responses with full details | Describes the observed response portfolio | Denominator depends on extraction, splitting and corpus size | Useful diagnostic within a country | Richer documentation can lower the score; unreliable league tables |

The recommended design removes hidden weighting and keeps disagreements, priorities and source gaps visible. It can be implemented without a third LLM stage. No method automatically converts policy prose into verified policy effectiveness.

## 10. Reference implementation and its limits

[score-bands.mjs](../reference/score-bands.mjs) consumes normalized, already source-checked assessments. It reads the editable [scoring configuration](../pipeline/scoring.json). [band-cases.json](../examples/band-cases.json) contains full synthetic inputs, while [score-bands.test.mjs](../reference/score-bands.test.mjs) tests ambiguity, missing evidence, identity, duplicates and the separate metrics.

The core input is `scope`, a fixed topic `profile`, resolved `evidence`, coherent `claims[].variants`, and `topics[].processing_complete`. A variant includes `policy_object_id`, statement type, conditionality, its admitted evidence IDs and the three delivery details. All details are explicitly present or null. Detail citations must belong to that coherent variant. Each variant has one claim owner; all variants of a claim share the same policy-object ID.

For more than one topic, `claims[].topic_projections` is required: one `{topic_id, variants:[...]}` projection per topic. Each retains all canonical variant IDs, but includes only statement type and delivery qualifications supported for that topic. It may downgrade a response to contextual evidence and omit delivery details; it cannot invent new evidence, a stronger response stage or new delivery qualifications. The engine computes topic metrics from these projections rather than inheriting the primary claim band. Source relevance is still checked upstream. Single-topic inputs need no projection wrapper.

Outputs expose `topics[].metrics`, `domains[].metrics` and, for country scope, `national.metrics`. Each metric contains its own P/A/U/N, lower/upper percentage and exact flag. Existing response-coverage fields remain aliases for compatibility. Internal claim band codes support diagnostics only; they are not headline UI ratings.

The seven allowed actor roles are responsible, implementing, financing, supporting, monitoring_reporting, consulted and unspecified; only the first two satisfy Who. Timeframe anchors are action or publication; only action qualifies. Deliverable kinds are quantified_output, named_asset, named_legal_instrument, named_milestone and generic_action; generic_action does not qualify.

`assessDataset` rejects malformed inputs. `assessDatasetSafely` returns unavailable with a null assessment on invalid input; it never silently substitutes zero. “Available” means calculable, not complete. The engine cannot prove source truth, semantic support, exhaustive search, correct policy identity, authoritative topic homes or raw-record ownership. Those remain upstream automatic-check and evaluation responsibilities.

[compare-snapshots.mjs](../reference/compare-snapshots.mjs) separately checks frozen basis metadata, exact selected source manifests, cutoffs, newer same-family editions and completeness before permitting a documentation arrow. Its [test cases](../reference/compare-snapshots.test.mjs) cover refresh events and suppression. Metadata checks are not proof that a source was correctly identified.

Run from the repository root:

```text
node docs/review/reference/score-bands.test.mjs
node docs/review/reference/compare-snapshots.test.mjs
node docs/review/reference/check-water.mjs
```

Changing display labels is a presentation edit. Changing qualification rules, topic scope or source profiles requires a versioned recomputation. Reuse stored facts when they establish the new rule; otherwise re-extract only affected material. There is no human approval queue before publication: bounded automated checks finish with either usable results or explicit incomplete states. Users may flag/hide results afterward; analytical exclusions create clearly labelled adjusted snapshots.
