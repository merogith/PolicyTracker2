// Topic and domain views for a country, following fresh-start/config/claims.json: findings that share
// a source record merge (here: a quote on the same document page), transitively; a merged finding
// keeps every topic of its members and counts once in each topic; its stage is the highest stage among
// its members. Domains come from topic placements, so domain counts overlap and are never added up.
//
// A country finding's topics are read from the document findings it cites (sources.itemRefs), so a
// re-tag of the document answers updates the country views without asking the model again.
import { PROMPT_VERSION } from "./analysis/prompt";
import { db } from "./db";
import { domainScore, RUBRIC, topicScore } from "./scoring";
import { loadTaxonomy } from "./taxonomy";
import { count, mergeUnits, stageSummary, type Unit } from "./topic-merge";

export { STAGE_KINDS, STAGE_OF, type MergedItem, type StageCounts, type StageSummary, type Trend, type Unit } from "./topic-merge";

type Json = Record<string, unknown>;

export async function countryTopics(countryId: string) {
  const tax = await loadTaxonomy();
  const domains = tax.domains.filter((d) => d.enabled);
  const version = new Map(domains.map((d) => [d.id, d.version]));
  const [summaries, docResults, documents] = await Promise.all([
    db.analysisResult.findMany({
      where: { countryId, scope: "country", status: "done", domainId: { in: domains.map((d) => d.id) } },
      include: { citations: { orderBy: [{ itemPath: "asc" }, { position: "asc" }] } },
    }),
    db.analysisResult.findMany({
      where: { countryId, scope: "document", status: "done", domainId: { in: domains.map((d) => d.id) }, document: { status: { notIn: ["deleting"] } } },
      select: { id: true, domainId: true, domainVersion: true, documentId: true, output: true, promptVersion: true, taxonomyVersion: true },
    }),
    db.document.findMany({ where: { countryId, status: { not: "deleting" } }, orderBy: [{ editionDate: "asc" }, { id: "asc" }], select: { id: true, kind: true, editionDate: true } }),
  ]);
  const current = summaries.filter((r) => version.get(r.domainId) === r.domainVersion);
  const currentDocs = docResults.filter((r) => version.get(r.domainId) === r.domainVersion);
  const docOutputs = new Map(docResults.map((r) => [r.id, r.output as Json]));
  const topicsAt = (resultId: string, path: string) => {
    const i = Number(path.split(".")[1]);
    const f = ((docOutputs.get(resultId)?.findings as Json[]) ?? [])[i];
    return ((f?.topic_ids as string[]) ?? []).filter((t) => tax.topic(t));
  };

  // Units: the findings of the combined summaries.
  const units: Unit[] = [];
  for (const r of current) {
    const domain = tax.domain(r.domainId)!;
    const output = r.output as Json;
    if (output.not_found) continue;
    const sources = (r.sources as Json | null) ?? {};
    const itemRefs = (sources.itemRefs ?? {}) as Record<string, Array<{ resultId: string; path: string }>>;
    ((output.findings as Json[]) ?? []).forEach((item, i) => {
      const path = `findings.${i}`;
      const topics = [...new Set((itemRefs[path] ?? []).flatMap((ref) => topicsAt(ref.resultId, ref.path)))].sort();
      units.push({
        domainId: domain.id,
        domainLabel: domain.label,
        path,
        kind: (item.kind as string | undefined) ?? null,
        text: item.text as string,
        topics,
        citations: r.citations
          .filter((c) => c.itemPath === path)
          .map((c) => ({ id: c.id, documentId: c.documentId, page: c.page, quote: c.quote, verified: c.verified })),
      });
    });
  }
  const merged = mergeUnits(units);
  const tagged = merged.filter((m) => m.topics.length > 0);
  const untagged = merged.filter((m) => m.topics.length === 0);

  const inTopic = (topicId: string) => tagged.filter((m) => m.topics.includes(topicId));
  const inDomain = (domainId: string) => tagged.filter((m) => m.topics.some((t) => tax.domainsOfTopic(t).includes(domainId)));

  // The newest edition with answers, for "latest edition vs earlier" trends.
  const answered = documents.filter((d) => currentDocs.some((r) => r.documentId === d.id));
  const latestDocument = answered.length ? answered[answered.length - 1].id : null;

  // Status, trend and score of every topic.
  const topicSummaries = new Map(
    tax.topics.map((t) => {
      const items = inTopic(t.id);
      const summary = stageSummary(items, latestDocument, answered.length);
      return [t.id, { topic: t, items, counts: count(items), summary, score: topicScore(summary.status) }] as const;
    }),
  );

  const domainRows = tax.domains.map((d) => {
    const items = inDomain(d.id);
    const topics = tax.topicsOfDomain(d.id);
    return {
      domain: d,
      counts: count(items),
      topicsTouched: topics.filter((t) => items.some((m) => m.topics.includes(t.id))).length,
      topicCount: topics.length,
      summary: stageSummary(items, latestDocument, answered.length),
      score: domainScore(topics.map((t) => topicSummaries.get(t.id)!.score)),
      /** The findings that went furthest, for a profile card. */
      highlights: [...items].sort((a, b) => (b.stage ?? -1) - (a.stage ?? -1)).slice(0, 3),
    };
  });

  // What each document's own answers cover, per domain (a finding counts once per domain).
  const docDomains = documents.map((doc) => {
    const perDomain = new Map<string, number>();
    for (const r of currentDocs.filter((x) => x.documentId === doc.id)) {
      const output = r.output as Json;
      if (output.not_found) continue;
      for (const item of (output.findings as Json[]) ?? []) {
        const ds = new Set(((item.topic_ids as string[]) ?? []).flatMap((t) => tax.domainsOfTopic(t)));
        for (const d of ds) perDomain.set(d, (perDomain.get(d) ?? 0) + 1);
      }
    }
    return { document: doc, perDomain };
  });

  // Concepts no topic fitted, as the documents' answers report them.
  const unmapped = new Map<string, Set<string>>();
  for (const r of currentDocs) {
    for (const item of ((r.output as Json).findings as Json[]) ?? []) {
      for (const c of (item.unmapped_concepts as string[]) ?? []) unmapped.set(c, (unmapped.get(c) ?? new Set()).add(r.documentId!));
    }
  }

  const outdated = [...current, ...currentDocs].filter((r) => r.promptVersion !== PROMPT_VERSION).length;
  const retagPending = currentDocs.filter((r) => r.taxonomyVersion !== tax.version).length;

  return {
    tax,
    ready: current.length > 0,
    domains: domainRows,
    docDomains,
    documents,
    untagged,
    unmapped: [...unmapped].map(([concept, docs]) => ({ concept, documents: [...docs].sort() })),
    outdated,
    retagPending,
    topicItems: inTopic,
    topicCounts: (topicId: string) => count(inTopic(topicId)),
    topics: [...topicSummaries.values()],
    topicSummary: (topicId: string) => topicSummaries.get(topicId),
    latestDocument,
    rubric: RUBRIC,
    mergedCount: merged.length,
    unitCount: units.length,
  };
}

export type CountryTopics = Awaited<ReturnType<typeof countryTopics>>;
