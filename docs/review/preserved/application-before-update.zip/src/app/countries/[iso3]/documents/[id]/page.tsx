import { Download } from "lucide-react";
import { notFound } from "next/navigation";
import { ActionButton } from "@/components/action-button";
import { AutoRefresh } from "@/components/auto-refresh";
import { KindChip } from "@/components/charts/kind";
import { DomainIndex } from "@/components/domain-index";
import { Fact, PageHeader } from "@/components/page-header";
import { PageViewer } from "@/components/page-viewer";
import { ResultCard } from "@/components/result-card";
import { StatusBadge } from "@/components/status-badge";
import { db } from "@/lib/db";
import { loadTaxonomy } from "@/lib/taxonomy";
import { documentCards, verifiedRate } from "@/lib/views";

const BUSY = ["uploaded", "extracting", "indexing", "analysing"];

export default async function DocumentPage({ params, searchParams }: PageProps<"/countries/[iso3]/documents/[id]">) {
  const { iso3, id } = await params;
  const sp = await searchParams;
  const doc = await db.document.findUnique({ where: { id }, include: { country: true, pages: { orderBy: { page: "asc" } } } });
  if (!doc || doc.country.iso3 !== iso3.toUpperCase() || doc.status === "deleting") notFound();

  const tax = await loadTaxonomy();
  const cards = await documentCards(doc.id, tax.domains, tax.version);
  const rate = verifiedRate(cards);
  const citeId = typeof sp.cite === "string" ? sp.cite : null;
  const cite = citeId ? await db.citation.findUnique({ where: { id: citeId } }) : null;
  const pageNumber = Number(sp.page) || cite?.page || 1;
  const unreadable = doc.pages.filter((p) => p.disposition === "unreadable").map((p) => p.page);
  const basePath = `/countries/${doc.country.iso3}/documents/${doc.id}`;

  return (
    <div>
      <PageHeader
        crumbs={[
          { label: "Countries", href: "/countries" },
          { label: doc.country.name, href: `/countries/${doc.country.iso3}?tab=${doc.id}` },
          { label: doc.id },
        ]}
        title={doc.title}
        meta={
          <>
            <span className="font-mono text-xs">{doc.id}</span>
            <KindChip kind={doc.kind} />
            <Fact>edition {doc.editionDate}</Fact>
            <Fact>{doc.pageCount ?? "?"} pages</Fact>
            {unreadable.length > 0 && <Fact tone="warn">no text on p. {unreadable.join(", ")}</Fact>}
            <StatusBadge status={doc.status} />
            {rate.total > 0 && (
              <Fact tone={rate.verified / rate.total >= 0.9 ? "ok" : "warn"}>
                {rate.verified}/{rate.total} quotes verified
              </Fact>
            )}
            <AutoRefresh active={BUSY.includes(doc.status) || cards.some((c) => c.pending)} />
          </>
        }
        actions={
          <>
            <a href={`/api/documents/${doc.id}/pdf?download`} className="btn">
              <Download className="size-3.5" aria-hidden /> Download PDF
            </a>
            <ActionButton url="/api/results/rerun" body={{ documentId: doc.id }} label="Re-run all domains" icon="rerun" confirm={`Ask every domain again of ${doc.id}?`} />
          </>
        }
      />
      {doc.error && <p className="mb-4 rounded-md bg-bad-soft px-3 py-2 text-sm text-bad-ink">{doc.error}</p>}

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div className="flex min-w-0 flex-col gap-2">
          <DomainIndex cards={cards} prefix="domain" />
          <div className="flex flex-col gap-5">
            {cards.map((card) => (
              <ResultCard key={card.domain.id} anchor={`domain-${card.domain.id}`} card={card} iso3={doc.country.iso3} rerun={{ documentId: doc.id }} showRaw />
            ))}
          </div>
        </div>
        <div className={`${cite || sp.page ? "order-first" : ""} xl:sticky xl:top-6 xl:order-none xl:self-start`}>
          <PageViewer
            pages={doc.pages}
            pageNumber={pageNumber}
            quote={cite && cite.documentId === doc.id ? cite.quote : null}
            basePath={basePath}
            pdfUrl={`/api/documents/${doc.id}/pdf`}
          />
        </div>
      </div>
    </div>
  );
}
