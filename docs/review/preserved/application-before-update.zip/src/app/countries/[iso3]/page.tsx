import { Download, FileStack, FileText, Layers, LayoutDashboard, Network, Plus } from "lucide-react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ActionButton } from "@/components/action-button";
import { AutoRefresh } from "@/components/auto-refresh";
import { CoverageHeatmap } from "@/components/charts/coverage-heatmap";
import { DocumentTimeline } from "@/components/charts/document-timeline";
import { DomainLegend, DomainRadial, DomainTiles } from "@/components/charts/domain-dashboard";
import { FiguresTable } from "@/components/charts/figures-table";
import { KindChip, KindDot } from "@/components/charts/kind";
import { VerifiedMeter } from "@/components/charts/verified-meter";
import { DomainsView, ScoreReading } from "@/components/domains-view";
import { DomainIndex } from "@/components/domain-index";
import { Fact, PageHeader } from "@/components/page-header";
import { ResultCard } from "@/components/result-card";
import { Section } from "@/components/section";
import { StatusBadge } from "@/components/status-badge";
import { Tabs } from "@/components/tabs";
import { UploadForm } from "@/components/upload-form";
import { getCountry } from "@/lib/countries";
import { db } from "@/lib/db";
import { countryOverview } from "@/lib/overview";
import type { Taxonomy } from "@/lib/taxonomy";
import { countryTopics, type CountryTopics } from "@/lib/topics";
import { countryCards, documentCards, verifiedRate } from "@/lib/views";
import { plural } from "@/lib/plural";

const BUSY = ["uploaded", "extracting", "indexing", "analysing", "deleting"];

export default async function CountryPage({ params, searchParams }: PageProps<"/countries/[iso3]">) {
  const { iso3 } = await params;
  const sp = await searchParams;
  const country = await getCountry(iso3);
  if (!country) notFound();

  const overview = await countryOverview(country.id);
  const documents = await db.document.findMany({
    where: { countryId: country.id, status: { not: "deleting" } },
    orderBy: [{ editionDate: "asc" }, { id: "asc" }],
    include: { _count: { select: { pages: { where: { disposition: "unreadable" } } } } },
  });
  const tab = typeof sp.tab === "string" ? sp.tab : documents.length ? "overview" : "documents";
  const topics = tab === "overview" || tab === "domains" ? await countryTopics(country.id) : null;
  const selectedDoc = documents.find((d) => d.id === tab) ?? null;
  const busy = overview.activeJobs > 0 || documents.some((d) => BUSY.includes(d.status));
  const base = `/countries/${country.iso3}`;
  const pct = overview.verified.total ? Math.round((100 * overview.verified.verified) / overview.verified.total) : null;

  return (
    <div>
      <PageHeader
        crumbs={[{ label: "Countries", href: "/countries" }, { label: country.name }]}
        title={
          <span className="flex flex-wrap items-center gap-3">
            {country.name}
            <span className="rounded-md bg-primary-soft px-2 py-0.5 font-mono text-sm font-medium text-primary-ink">{country.iso3}</span>
          </span>
        }
        meta={
          <>
            <Fact icon={FileStack}>{documents.length} document{documents.length === 1 ? "" : "s"}</Fact>
            <Fact icon={Layers}>
              {overview.summariesDone}/{overview.summariesTotal} combined summaries
            </Fact>
            {pct !== null && <Fact tone={pct >= 90 ? "ok" : "warn"}>{pct}% quotes verified</Fact>}
            <Fact>${overview.spentUsd.toFixed(2)} spent</Fact>
            <AutoRefresh active={busy} />
          </>
        }
        actions={
          <>
            <a href={`/api/countries/${country.iso3}/export.json`} className="btn">
              <Download className="size-3.5" aria-hidden /> Export JSON
            </a>
            <Link href={`${base}?tab=documents#upload`} className="btn btn-primary">
              <Plus className="size-3.5" aria-hidden /> Add document
            </Link>
          </>
        }
      />

      <Tabs
        label="Country sections"
        active={selectedDoc ? selectedDoc.id : tab}
        items={[
          { id: "overview", href: `${base}?tab=overview`, label: <><LayoutDashboard className="size-4" aria-hidden /> Overview</> },
          {
            id: "summary",
            href: `${base}?tab=summary`,
            label: <><Layers className="size-4" aria-hidden /> Combined summary</>,
            hint: <span className="rounded-full bg-surface-2 px-1.5 text-[11px] text-muted tabular">{overview.summariesDone}</span>,
          },
          { id: "domains", href: `${base}?tab=domains`, label: <><Network className="size-4" aria-hidden /> Domains & topics</> },
          ...documents.map((d) => ({
            id: d.id,
            href: `${base}?tab=${d.id}`,
            label: (
              <>
                <KindDot kind={d.kind} /> <span className="font-mono text-[13px]">{d.id}</span>
              </>
            ),
            hint: BUSY.includes(d.status) ? <span className="pulse size-1.5 rounded-full bg-primary" title={d.status} /> : d.status === "failed" ? <span className="size-1.5 rounded-full bg-bad" title="failed" /> : undefined,
          })),
          {
            id: "documents",
            href: `${base}?tab=documents`,
            label: <><FileText className="size-4" aria-hidden /> Documents</>,
            hint: <span className="rounded-full bg-surface-2 px-1.5 text-[11px] text-muted tabular">{documents.length}</span>,
          },
        ]}
      />

      {tab === "overview" && <OverviewTab overview={overview} topics={topics!} iso3={country.iso3} />}
      {tab === "domains" && (
        <DomainsView
          data={topics!}
          iso3={country.iso3}
          domainId={typeof sp.domain === "string" ? sp.domain : undefined}
          topicId={typeof sp.topic === "string" ? sp.topic : undefined}
          view={typeof sp.view === "string" ? sp.view : undefined}
          filter={typeof sp.filter === "string" ? sp.filter : undefined}
        />
      )}
      {tab === "summary" && <SummaryTab countryId={country.id} iso3={country.iso3} tax={overview.tax} hasDocuments={documents.length > 0} />}
      {selectedDoc && <DocumentTab doc={selectedDoc} iso3={country.iso3} tax={overview.tax} />}
      {tab === "documents" && (
        <div className="flex flex-col gap-6">
          <Section id="upload" title="Add a document" description="Upload a PDF of a climate or disaster policy document. It is read, indexed and asked every domain's question without further steps.">
            <UploadForm iso3={country.iso3} />
          </Section>
          <Section title="Documents" description="Every document of this country, oldest edition first.">
            {documents.length === 0 ? (
              <p className="text-sm text-muted">No documents yet. Add the country&apos;s NDC, adaptation plan or disaster-risk strategy above.</p>
            ) : (
              <ul className="flex flex-col divide-y divide-border">
                {documents.map((d) => (
                  <li key={d.id} className="flex flex-wrap items-center gap-x-4 gap-y-2 py-3">
                    <div className="flex min-w-0 flex-1 flex-col gap-1">
                      <Link href={`${base}?tab=${d.id}`} className="flex items-center gap-2 font-medium hover:underline">
                        <span className="truncate">{d.title}</span>
                      </Link>
                      <p className="flex flex-wrap items-center gap-2 text-xs text-muted">
                        <span className="font-mono">{d.id}</span>
                        <KindChip kind={d.kind} />
                        <span className="tabular">edition {d.editionDate}</span>
                        <span className="tabular">{d.pageCount ?? "?"} pages</span>
                        {d._count.pages > 0 && <span className="rounded-full bg-warn-soft px-2 py-0.5 text-warn-ink">{d._count.pages} unreadable</span>}
                      </p>
                      {d.error && <p className="text-xs text-bad-ink">{d.error}</p>}
                    </div>
                    <StatusBadge status={d.status} />
                    <div className="flex gap-2">
                      <Link href={`${base}/documents/${d.id}`} className="btn btn-sm">
                        Pages & answers
                      </Link>
                      <ActionButton url="/api/results/rerun" body={{ documentId: d.id }} label="Re-run" icon="rerun" size="sm" confirm={`Ask every domain again of ${d.id}?`} />
                      <ActionButton
                        url={`/api/documents/${d.id}`}
                        method="DELETE"
                        label="Delete"
                        icon="delete"
                        variant="danger"
                        size="sm"
                        confirm={`Delete ${d.id} and its answers? The combined summaries will be re-run without it.`}
                      />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Section>
          <Section title="Delete this country" description="Removes every document, answer and summary of this country, and its files at OpenAI. This cannot be undone.">
            <div>
              <ActionButton
                url={`/api/countries/${country.iso3}`}
                method="DELETE"
                label={`Delete ${country.name}`}
                icon="delete"
                variant="danger"
                confirm={`Delete ${country.name}, all its documents and results, and its files at OpenAI?`}
                redirectTo="/countries"
              />
            </div>
          </Section>
        </div>
      )}
    </div>
  );
}

function OverviewTab({ overview, topics, iso3 }: { overview: Awaited<ReturnType<typeof countryOverview>>; topics: CountryTopics; iso3: string }) {
  if (overview.documents.length === 0) {
    return (
      <div className="panel flex flex-col items-start gap-3 p-6">
        <h2 className="text-base font-semibold">No documents yet</h2>
        <p className="max-w-prose text-sm text-muted">Upload this country&apos;s policy documents. Each one is asked every domain&apos;s question, and this page then shows how far its responses have gone, what each document covers, and its key figures.</p>
        <Link href={`/countries/${iso3}?tab=documents#upload`} className="btn btn-primary">
          <Plus className="size-3.5" aria-hidden /> Add a document
        </Link>
      </div>
    );
  }
  const kinds = [...new Set(overview.documents.map((d) => d.kind))];
  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <div className="panel flex flex-col gap-2 p-4 sm:p-5">
          <span className="text-sm text-muted">Documents</span>
          <span className="text-3xl font-semibold tracking-tight">{overview.documents.length}</span>
          <span className="flex flex-wrap gap-1.5">
            {kinds.map((k) => (
              <KindChip key={k} kind={k} />
            ))}
          </span>
        </div>
        <div className="panel flex flex-col gap-2 p-4 sm:p-5">
          <span className="text-sm text-muted">Pages read</span>
          <span className="text-3xl font-semibold tracking-tight">{overview.pages.read}</span>
          <span className={`text-xs ${overview.pages.unreadable ? "text-warn-ink" : "text-muted"}`}>
            {overview.pages.unreadable ? `${plural(overview.pages.unreadable, "page")} without a text layer ${overview.pages.unreadable === 1 ? "was" : "were"} not analysed` : "every page had text"}
          </span>
        </div>
        <div className="panel flex flex-col gap-2 p-4 sm:p-5">
          <span className="text-sm text-muted">Combined summaries</span>
          <span className="text-3xl font-semibold tracking-tight">
            {overview.summariesDone}
            <span className="text-lg font-normal text-muted">/{overview.summariesTotal}</span>
          </span>
          <Link href={`/countries/${iso3}?tab=summary`} className="text-xs text-primary-ink hover:underline">
            Read the combined summary
          </Link>
        </div>
        <div className="panel p-4 sm:p-5">
          <VerifiedMeter verified={overview.verified.verified} total={overview.verified.total} />
        </div>
      </div>

      {topics.ready && (
        <Section
          title="Domain dashboard"
          description="One tile per domain of the taxonomy. Colour shows the furthest response stage the documents describe; the arrow compares the latest edition with earlier ones; the chip is the score from the scoring rubric."
          actions={
            <Link href={`/countries/${iso3}?tab=domains&view=topics`} className="btn btn-sm">
              Status of all 64 topics
            </Link>
          }
        >
          <DomainTiles domains={topics.domains} base={`/countries/${iso3}?tab=domains`} />
          <DomainLegend />
        </Section>
      )}

      {topics.ready && (
        <div className="grid gap-6 xl:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
          <Section title="Findings around the domains" description="The same 16 domains as a wheel: a bigger wedge means more distinct findings.">
            <DomainRadial domains={topics.domains} base={`/countries/${iso3}?tab=domains`} />
          </Section>
          <ScoreReading data={topics} />
        </div>
      )}

      <Section title="Documents over time" description="Each document at its edition date, coloured by kind. Select one to open its answers.">
        <DocumentTimeline documents={overview.documents} iso3={iso3} />
      </Section>

      <Section title="What each document covers" description="How many findings each document's answer has per domain. Gaps show where a document says nothing on a domain.">
        <CoverageHeatmap overview={overview} iso3={iso3} />
      </Section>

      <Section title="Targets and figures" description="Every figure stated in the combined summaries, exactly as stated. Conditional and unconditional figures are kept apart and never combined.">
        <FiguresTable figures={overview.figures} />
      </Section>
    </div>
  );
}

async function SummaryTab({ countryId, iso3, tax, hasDocuments }: { countryId: string; iso3: string; tax: Taxonomy; hasDocuments: boolean }) {
  if (!hasDocuments) return <p className="text-sm text-muted">Add documents first; the combined summary is built from their answers.</p>;
  const cards = await countryCards(countryId, tax.domains, tax.version);
  return (
    <div className="flex flex-col gap-2">
      <div className="mb-2 flex flex-wrap items-start justify-between gap-3">
        <p className="max-w-prose text-sm text-muted">
          One answer per domain across all of this country&apos;s documents, with what each document says and what changed between editions. It is built from the documents&apos; own answers, so every quote comes from a document page.
        </p>
        <ActionButton url="/api/results/rerun" body={{ countryId }} label="Re-run summaries" icon="rerun" confirm="Run every combined summary again?" />
      </div>
      <DomainIndex cards={cards} prefix="summary" />
      <div className="grid items-start gap-5 lg:grid-cols-2">
        {cards.map((card) => (
          <ResultCard key={card.domain.id} anchor={`summary-${card.domain.id}`} card={card} iso3={iso3} rerun={{ countryId }} />
        ))}
      </div>
    </div>
  );
}

async function DocumentTab({
  doc,
  iso3,
  tax,
}: {
  doc: { id: string; title: string; kind: string; editionDate: string; pageCount: number | null; status: string; error: string | null };
  iso3: string;
  tax: Taxonomy;
}) {
  const cards = await documentCards(doc.id, tax.domains, tax.version);
  const rate = verifiedRate(cards);
  return (
    <div className="flex flex-col gap-2">
      <div className="mb-2 flex flex-wrap items-start justify-between gap-3">
        <div className="flex flex-col gap-1.5">
          <h2 className="text-lg font-semibold">{doc.title}</h2>
          <p className="flex flex-wrap items-center gap-2 text-xs text-muted">
            <KindChip kind={doc.kind} />
            <span className="tabular">edition {doc.editionDate}</span>
            <span className="tabular">{doc.pageCount ?? "?"} pages</span>
            <StatusBadge status={doc.status} />
            {rate.total > 0 && (
              <span className="tabular">
                {rate.verified}/{rate.total} quotes verified
              </span>
            )}
          </p>
          {doc.error && <p className="text-xs text-bad-ink">{doc.error}</p>}
        </div>
        <div className="flex gap-2">
          <Link href={`/countries/${iso3}/documents/${doc.id}`} className="btn">
            <FileText className="size-3.5" aria-hidden /> Open with page viewer
          </Link>
          <ActionButton url="/api/results/rerun" body={{ documentId: doc.id }} label="Re-run all domains" icon="rerun" confirm={`Ask every domain again of ${doc.id}?`} />
        </div>
      </div>
      <DomainIndex cards={cards} prefix="domain" />
      <div className="grid items-start gap-5 lg:grid-cols-2">
        {cards.map((card) => (
          <ResultCard key={card.domain.id} anchor={`domain-${card.domain.id}`} card={card} iso3={iso3} rerun={{ documentId: doc.id }} />
        ))}
      </div>
    </div>
  );
}
