import { ArrowRight, Globe2 } from "lucide-react";
import Link from "next/link";
import { CountryDomainMatrix } from "@/components/charts/country-matrix";
import { KindChip } from "@/components/charts/kind";
import { CreateCountryForm } from "@/components/create-country-form";
import { PageHeader } from "@/components/page-header";
import { Section } from "@/components/section";
import { StatusBadge } from "@/components/status-badge";
import { domainHue, hue } from "@/lib/colors";
import { db } from "@/lib/db";
import { countryTopics } from "@/lib/topics";
import { loadTaxonomy } from "@/lib/taxonomy";

export default async function CountriesPage({ searchParams }: PageProps<"/countries">) {
  const sp = await searchParams;
  const mode = sp.matrix === "score" ? "score" : "stage";
  const [countries, tax] = await Promise.all([
    db.country.findMany({
      where: { status: "active" },
      orderBy: { name: "asc" },
      include: {
        documents: { where: { status: { not: "deleting" } }, select: { id: true, kind: true, status: true }, orderBy: { editionDate: "asc" } },
        results: {
          where: { scope: "country", status: "done" },
          select: { domainId: true, domainVersion: true, output: true },
        },
      },
    }),
    loadTaxonomy(),
  ]);
  const domains = tax.domains.filter((d) => d.enabled);
  const matrixRows = await Promise.all(
    countries
      .filter((c) => c.documents.length > 0)
      .map(async (c) => ({ iso3: c.iso3, name: c.name, documents: c.documents.length, topics: await countryTopics(c.id) })),
  );
  const perCountry = await Promise.all(
    countries.map(async (c) => {
      const cites = await db.citation.groupBy({ by: ["verified"], where: { result: { scope: "document", countryId: c.id } }, _count: true });
      const total = cites.reduce((s, x) => s + x._count, 0);
      const ok = cites.find((x) => x.verified)?._count ?? 0;
      return { id: c.id, total, ok };
    }),
  );

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Countries" meta={<span>Each country holds its policy documents, the answer to every domain&apos;s question, and a combined summary per domain.</span>} />

      {countries.length === 0 ? (
        <div className="panel flex flex-col items-start gap-3 p-6">
          <Globe2 className="size-8 text-primary" aria-hidden />
          <h2 className="text-base font-semibold">Start with a country</h2>
          <p className="max-w-prose text-sm text-muted">Add a country below, then upload its NDC, adaptation plan or disaster-risk strategy. Analysis starts on its own.</p>
        </div>
      ) : (
        <ul className="flex flex-col gap-3">
          {countries.map((c) => {
            const kinds = [...new Set(c.documents.map((d) => d.kind))];
            const statuses = new Map<string, number>();
            for (const d of c.documents) statuses.set(d.status, (statuses.get(d.status) ?? 0) + 1);
            const v = perCountry.find((p) => p.id === c.id)!;
            return (
              <li key={c.id}>
                <Link href={`/countries/${c.iso3}`} className="panel group flex flex-wrap items-center gap-x-6 gap-y-3 p-4 transition-colors hover:border-primary">
                  <div className="flex min-w-48 flex-1 items-center gap-3">
                    <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-primary-soft font-mono text-sm font-semibold text-primary-ink">{c.iso3}</span>
                    <div className="min-w-0">
                      <p className="truncate font-semibold group-hover:text-primary-ink">{c.name}</p>
                      <p className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-muted">
                        {c.documents.length} document{c.documents.length === 1 ? "" : "s"}
                        {kinds.map((k) => (
                          <KindChip key={k} kind={k} />
                        ))}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <span className="text-[11px] text-muted">Combined summary per domain</span>
                    <span className="flex gap-1" aria-label="Domains with findings in the combined summary">
                      {domains.map((k) => {
                        const r = c.results.find((x) => x.domainId === k.id && x.domainVersion === k.version);
                        const out = r?.output as { not_found?: boolean } | undefined;
                        const state = !r ? "pending" : out?.not_found ? "not found" : "found";
                        return (
                          <span
                            key={k.id}
                            style={hue(domainHue(k.id))}
                            title={`${k.label}: ${state}`}
                            className={`size-3.5 rounded-[4px] ${state === "found" ? "hue-dot" : state === "not found" ? "hue-ring border-2" : "bg-surface-2"}`}
                          />
                        );
                      })}
                    </span>
                  </div>

                  <div className="flex w-36 flex-col gap-1">
                    <span className="text-[11px] text-muted">Quotes verified</span>
                    {v.total ? (
                      <>
                        <span className="flex h-1.5 gap-[2px] overflow-hidden rounded-full">
                          <span style={{ width: `${(100 * v.ok) / v.total}%`, background: "var(--status-good)" }} />
                          {v.ok < v.total && <span className="flex-1" style={{ background: "var(--status-critical)" }} />}
                        </span>
                        <span className="text-xs tabular">{Math.round((100 * v.ok) / v.total)}%</span>
                      </>
                    ) : (
                      <span className="text-xs text-muted">no quotes yet</span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {[...statuses].map(([s, n]) => (
                      <StatusBadge key={s} status={s} label={`${n} ${s}`} />
                    ))}
                    {c.documents.length === 0 && <span className="text-xs text-muted">no documents yet</span>}
                  </div>
                  <ArrowRight className="size-4 text-muted transition-transform group-hover:translate-x-0.5 group-hover:text-primary" aria-hidden />
                </Link>
              </li>
            );
          })}
        </ul>
      )}

      {matrixRows.some((r) => r.topics.ready) && (
        <Section
          title="Countries × domains"
          description="Every country against the 16 domains of the taxonomy. Select a cell to open that country's domain."
          actions={
            <nav aria-label="Matrix view" className="flex gap-1 rounded-lg bg-surface-2 p-1">
              <Link
                href="/countries"
                aria-current={mode === "stage" ? "page" : undefined}
                className={`rounded-md px-3 py-1 text-xs font-medium ${mode === "stage" ? "bg-surface text-primary-ink shadow-card" : "text-muted hover:text-foreground"}`}
              >
                Stages
              </Link>
              <Link
                href="/countries?matrix=score"
                aria-current={mode === "score" ? "page" : undefined}
                className={`rounded-md px-3 py-1 text-xs font-medium ${mode === "score" ? "bg-surface text-primary-ink shadow-card" : "text-muted hover:text-foreground"}`}
              >
                Scores
              </Link>
            </nav>
          }
        >
          <CountryDomainMatrix rows={matrixRows} mode={mode} />
        </Section>
      )}

      <Section id="add" title="Add a country" description="Use the three-letter ISO code. A search index for its documents is created at OpenAI.">
        <CreateCountryForm />
      </Section>
    </div>
  );
}
