import { Fact, PageHeader } from "@/components/page-header";
import { TaxonomyEditor, type EditorDomain, type EditorTopic } from "@/components/taxonomy-editor";
import { db } from "@/lib/db";
import { loadTaxonomy } from "@/lib/taxonomy";

export default async function TaxonomyPage() {
  const tax = await loadTaxonomy();
  const [answers, retired] = await Promise.all([
    db.analysisResult.groupBy({ by: ["domainId"], where: { scope: "document", status: "done" }, _count: true }),
    db.topic.count({ where: { retiredAt: { not: null } } }),
  ]);
  const domains: EditorDomain[] = (
    await db.domain.findMany({ where: { retiredAt: null }, orderBy: { order: "asc" } })
  ).map((d) => ({
    id: d.id,
    prefix: d.prefix,
    label: d.label,
    definition: d.definition,
    groups: d.groups as EditorDomain["groups"],
    searchHints: d.searchHints as string[],
    maxResults: d.maxResults,
    version: d.version,
    enabled: d.enabled,
    answers: answers.find((a) => a.domainId === d.id)?._count ?? 0,
  }));
  const topics: EditorTopic[] = tax.topics.map((t) => ({
    id: t.id,
    label: t.label,
    definition: t.definition,
    placements: t.placements,
    routing: t.routing,
    legacyIds: t.legacyIds,
  }));

  return (
    <div>
      <PageHeader
        crumbs={[{ label: "Domains & topics" }]}
        title="Domains & topics"
        meta={
          <>
            <Fact tone="primary">taxonomy {tax.version}</Fact>
            <Fact>{domains.length} domains</Fact>
            <Fact>{topics.length} topics</Fact>
            {retired > 0 && <Fact>{retired} retired</Fact>}
          </>
        }
      />
      <TaxonomyEditor domains={domains} topics={topics} />
    </div>
  );
}
