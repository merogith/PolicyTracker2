import { db } from "@/lib/db";
import { readPdf } from "@/lib/storage";

export async function GET(req: Request, ctx: RouteContext<"/api/documents/[id]/pdf">) {
  const { id } = await ctx.params;
  const doc = await db.document.findUnique({ where: { id } });
  if (!doc || doc.status === "deleting") return new Response("Not found", { status: 404 });
  const data = await readPdf(doc.pdfPath);
  const download = new URL(req.url).searchParams.has("download");
  return new Response(new Uint8Array(data), {
    headers: {
      "content-type": "application/pdf",
      "content-disposition": `${download ? "attachment" : "inline"}; filename="${doc.id}.pdf"`,
    },
  });
}
