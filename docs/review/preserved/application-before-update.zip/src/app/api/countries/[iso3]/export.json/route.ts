import { db } from "@/lib/db";
import { loadTaxonomy } from "@/lib/taxonomy";

/** Everything known about one country: documents, domain answers, combined summaries and citations. */
export async function GET(_req: Request, ctx: RouteContext<"/api/countries/[iso3]/export.json">) {
  const { iso3 } = await ctx.params;
  const country = await db.country.findFirst({ where: { iso3: iso3.toUpperCase(), status: "active" } });
  if (!country) return Response.json({ error: `No country ${iso3}` }, { status: 404 });

  const tax = await loadTaxonomy();
  const [documents, results] = await Promise.all([
    db.document.findMany({
      where: { countryId: country.id, status: { not: "deleting" } },
      orderBy: [{ editionDate: "asc" }, { id: "asc" }],
      include: { pages: { select: { page: true, label: true, disposition: true }, orderBy: { page: "asc" } } },
    }),
    db.analysisResult.findMany({
      where: { countryId: country.id, domain: { retiredAt: null } },
      orderBy: [{ domainId: "asc" }, { slot: "asc" }, { domainVersion: "desc" }],
      include: { citations: { orderBy: [{ itemPath: "asc" }, { position: "asc" }] } },
    }),
  ]);
  const domainVersion = new Map(tax.domains.map((d) => [d.id, d.version]));

  const body = {
    exported_at: new Date().toISOString(),
    taxonomy: { version: tax.version, download: "/api/taxonomy" },
    country: { iso3: country.iso3, name: country.name, vector_store_id: country.vectorStoreId },
    documents: documents.map((d) => ({
      id: d.id,
      title: d.title,
      kind: d.kind,
      edition_date: d.editionDate,
      language: d.language,
      page_count: d.pageCount,
      unreadable_pages: d.pages.filter((p) => p.disposition === "unreadable").map((p) => p.page),
      status: d.status,
      sha256: d.sha256,
      openai_file_id: d.openaiFileId,
    })),
    domains: tax.domains.map((d) => ({
      id: d.id,
      prefix: d.prefix,
      label: d.label,
      definition: d.definition,
      question_version: d.version,
      enabled: d.enabled,
      topics: tax.topicsOfDomain(d.id).map((t) => t.id),
    })),
    results: results.map((r) => ({
      domain_id: r.domainId,
      question_version: r.domainVersion,
      stale: r.domainVersion < (domainVersion.get(r.domainId) ?? r.domainVersion),
      scope: r.scope,
      document_id: r.documentId,
      status: r.status,
      output: r.output,
      model: r.model,
      prompt_version: r.promptVersion,
      taxonomy_version: r.taxonomyVersion,
      usage: { input_tokens: r.inputTokens, cached_tokens: r.cachedTokens, output_tokens: r.outputTokens, reasoning_tokens: r.reasoningTokens, file_search_calls: r.fileSearchCalls },
      cost_usd: r.costUsd,
      sources: r.sources,
      error: r.error,
      finished_at: r.finishedAt,
      citations: r.citations.map((c) => ({
        item: c.itemPath || null,
        document_id: c.documentId,
        page: c.page,
        cited_page: c.citedPage,
        quote: c.quote,
        verified: c.verified,
      })),
    })),
  };
  return new Response(JSON.stringify(body, null, 2), {
    headers: {
      "content-type": "application/json",
      "content-disposition": `attachment; filename="${country.iso3}-export.json"`,
    },
  });
}
