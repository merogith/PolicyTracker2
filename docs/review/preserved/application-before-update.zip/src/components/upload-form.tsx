"use client";

import { FileUp, Loader2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { DOCUMENT_KINDS } from "@/lib/domain";

export function UploadForm({ iso3 }: { iso3: string }) {
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);
  const [busy, setBusy] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [message, setMessage] = useState<{ tone: "ok" | "bad"; text: string } | null>(null);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch(`/api/countries/${iso3}/documents`, { method: "POST", body: new FormData(e.currentTarget) });
      const json = (await res.json()) as { id?: string; error?: string; estimateUsd?: number; pageCount?: number };
      if (!res.ok) return setMessage({ tone: "bad", text: json.error ?? `Upload failed (HTTP ${res.status})` });
      formRef.current?.reset();
      setFileName(null);
      const cost = json.estimateUsd !== undefined ? ` Estimated cost about $${json.estimateUsd.toFixed(2)}.` : "";
      setMessage({ tone: "ok", text: `Uploaded as ${json.id} (${json.pageCount} pages). Reading, indexing and analysis have started.${cost}` });
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <form ref={formRef} onSubmit={submit} className="flex flex-col gap-4">
      <label className="flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-border-strong bg-surface-2 px-4 py-6 text-center transition-colors hover:border-primary hover:bg-primary-soft focus-within:border-primary">
        <FileUp className="size-6 text-primary" aria-hidden />
        <span className="text-sm font-medium">{fileName ?? "Choose a PDF"}</span>
        <span className="text-xs text-muted">Up to 50 MB. Scanned pages without text are reported, not analysed.</span>
        <input name="file" type="file" accept="application/pdf" required className="sr-only" onChange={(e) => setFileName(e.target.files?.[0]?.name ?? null)} />
      </label>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[2fr_1.4fr_1fr_0.6fr]">
        <label className="label">
          Title
          <input name="title" required placeholder="e.g. NDC 3.0" className="field" />
        </label>
        <label className="label">
          Kind
          <select name="kind" required className="field" defaultValue="NDC">
            {DOCUMENT_KINDS.map((k) => (
              <option key={k.id} value={k.id}>
                {k.id}: {k.label}
              </option>
            ))}
          </select>
        </label>
        <label className="label">
          Edition date
          <input name="editionDate" type="date" required className="field" />
        </label>
        <label className="label">
          Language
          <input name="language" placeholder="en" className="field" />
        </label>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <button disabled={busy} className="btn btn-primary">
          {busy ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : <FileUp className="size-3.5" aria-hidden />}
          {busy ? "Uploading…" : "Upload and analyse"}
        </button>
        {message && (
          <p role="status" className={`rounded-md px-2.5 py-1.5 text-sm ${message.tone === "ok" ? "bg-ok-soft text-ok-ink" : "bg-bad-soft text-bad-ink"}`}>
            {message.text}
          </p>
        )}
      </div>
    </form>
  );
}
