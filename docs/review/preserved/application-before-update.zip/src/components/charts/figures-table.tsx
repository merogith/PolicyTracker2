import { CONDITIONALITY, domainHue, FINDING_KINDS, hue } from "@/lib/colors";
import type { CountryOverview } from "@/lib/overview";

/** Every figure stated in the combined summaries, exactly as stated; never combined. */
export function FiguresTable({ figures }: { figures: CountryOverview["figures"] }) {
  if (figures.length === 0) return <p className="text-sm text-muted">No figures yet. Targets, costs and other numbers appear here once the combined summaries are ready.</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[44rem] text-left text-sm">
        <thead className="text-xs text-muted">
          <tr className="border-b border-border">
            <th className="py-2 pr-4 font-medium">Finding</th>
            <th className="py-2 pr-4 font-medium">As stated</th>
            <th className="py-2 pr-4 font-medium">Period</th>
            <th className="py-2 pr-4 font-medium">Condition</th>
            <th className="py-2 pr-4 font-medium">Stage</th>
            <th className="py-2 font-medium">Documents</th>
          </tr>
        </thead>
        <tbody>
          {figures.map((f, i) => {
            const c = CONDITIONALITY[f.conditionality] ?? CONDITIONALITY.not_stated;
            return (
              <tr key={i} className="border-b border-border align-top last:border-0">
                <td className="py-2 pr-4">
                  <span className="line-clamp-2">{f.finding}</span>
                  <span className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-muted">
                    {f.domains.map((d) => (
                      <span key={d.id} style={hue(domainHue(d.id))} className="inline-flex items-center gap-1">
                        <span className="hue-dot size-1.5 rounded-full" />
                        {d.label}
                      </span>
                    ))}
                  </span>
                </td>
                <td className="py-2 pr-4 font-semibold whitespace-nowrap">
                  {f.valueAsStated}
                  {f.unit && !f.valueAsStated.includes(f.unit) ? <span className="font-normal text-muted"> {f.unit}</span> : null}
                </td>
                <td className="py-2 pr-4 tabular">{f.period ?? "–"}</td>
                <td className="py-2 pr-4">
                  <span style={hue(c.hue)} className="hue-soft rounded-full px-2 py-0.5 text-xs font-medium whitespace-nowrap">
                    {c.label}
                  </span>
                </td>
                <td className="py-2 pr-4 text-xs">{FINDING_KINDS[f.kind]?.label ?? f.kind}</td>
                <td className="py-2 font-mono text-xs">{f.documents.join(", ") || "–"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
