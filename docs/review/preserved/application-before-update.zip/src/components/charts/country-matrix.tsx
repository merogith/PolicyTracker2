import { ArrowDownRight, ArrowRight, ArrowUpRight, CornerDownRight, Sparkles } from "lucide-react";
import Link from "next/link";
import { RUBRIC } from "@/lib/scoring";
import type { CountryTopics } from "@/lib/topics";
import { DomainLegend } from "./domain-dashboard";
import { scoreBucket, statusColors, statusLabel, trendLabel } from "./stage";
import { ChartTooltips } from "./tooltip";

const TREND_ICON = { further: ArrowUpRight, same: ArrowRight, less: ArrowDownRight, new: Sparkles, not_repeated: CornerDownRight } as const;

export interface MatrixRow {
  iso3: string;
  name: string;
  documents: number;
  topics: CountryTopics;
}

/** Countries down, domains across. Stage view by default; score view shows the scoring layer instead. */
export function CountryDomainMatrix({ rows, mode }: { rows: MatrixRow[]; mode: "stage" | "score" }) {
  const domains = rows[0]?.topics.tax.domains ?? [];
  return (
    <figure className="flex flex-col gap-3">
      <ChartTooltips className="overflow-x-auto">
        <table className="w-full min-w-[64rem] border-separate border-spacing-[3px] text-xs">
          <thead>
            <tr>
              <th className="sticky left-0 z-10 bg-surface pr-2 text-left align-bottom font-medium text-muted">Country</th>
              <th className="px-1 text-center align-bottom font-medium text-muted">Docs</th>
              {domains.map((d) => (
                <th key={d.id} className="w-16 px-0.5 pb-1 text-center align-bottom font-medium" title={d.label}>
                  <span className="block font-mono text-[11px] font-semibold">{d.prefix}</span>
                  <span className="line-clamp-2 block text-[10px] leading-tight font-normal text-muted">{d.label}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.iso3}>
                <th scope="row" className="sticky left-0 z-10 bg-surface pr-2 text-left font-normal">
                  <Link href={`/countries/${r.iso3}?tab=overview`} className="flex items-center gap-1.5 text-[13px] font-medium hover:underline">
                    {r.name} <span className="font-mono text-[10px] text-muted">{r.iso3}</span>
                  </Link>
                </th>
                <td className="text-center tabular text-muted">{r.documents}</td>
                {r.topics.domains.map((d) => {
                  const href = `/countries/${r.iso3}?tab=domains&domain=${d.domain.id}`;
                  const tipLabel = `${r.name} · ${d.domain.label}`;
                  if (!r.topics.ready) {
                    return (
                      <td key={d.domain.id} className="h-9 rounded-[4px] bg-surface-2 text-center text-muted">
                        ·
                      </td>
                    );
                  }
                  if (mode === "score") {
                    const b = d.score.scored ? scoreBucket(d.score.sum, d.score.topics) : null;
                    return (
                      <td key={d.domain.id} className="p-0">
                        <Link
                          href={href}
                          data-tip-value={d.score.scored ? `Score ${d.score.sum > 0 ? "+" : ""}${d.score.sum} of ${d.score.topics} topics` : "Not scored (no findings)"}
                          data-tip-label={tipLabel}
                          className="flex h-9 items-center justify-center rounded-[4px] font-semibold tabular transition-[filter] hover:brightness-105"
                          style={b ? { background: `var(--score-${b})`, color: `var(--score-ink-${b})` } : { background: "var(--surface-2)", color: "var(--muted)" }}
                        >
                          {d.score.scored ? `${d.score.sum > 0 ? "+" : ""}${d.score.sum}` : "–"}
                        </Link>
                      </td>
                    );
                  }
                  const { fill } = statusColors(d.summary.status);
                  const Icon = d.summary.trend ? TREND_ICON[d.summary.trend] : null;
                  return (
                    <td key={d.domain.id} className="p-0">
                      <Link
                        href={href}
                        data-tip-value={`${statusLabel(d.summary.status)} · ${d.counts.total} finding${d.counts.total === 1 ? "" : "s"}`}
                        data-tip-label={`${tipLabel} · ${trendLabel(d.summary.trend)}`}
                        aria-label={`${tipLabel}: ${statusLabel(d.summary.status)}, ${d.counts.total} findings, ${trendLabel(d.summary.trend)}`}
                        className="flex h-9 items-center justify-center rounded-[4px] transition-[filter] hover:brightness-105"
                        style={{ background: d.counts.total ? fill : "var(--surface-2)" }}
                      >
                        {d.counts.total > 0 ? (
                          <span className="inline-flex items-center gap-0.5 rounded-full bg-surface px-1.5 py-px text-[11px] font-semibold text-foreground tabular">
                            {d.counts.total}
                            {Icon && <Icon className="size-3" aria-hidden />}
                          </span>
                        ) : (
                          <span className="text-muted">·</span>
                        )}
                      </Link>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </ChartTooltips>
      {mode === "stage" ? (
        <DomainLegend />
      ) : (
        <ul className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-muted">
          {[
            ["neg-2", "Well below zero"],
            ["neg-1", "Below zero"],
            ["0", "Zero"],
            ["pos-1", "Above zero"],
            ["pos-2", "Responses in most topics"],
          ].map(([b, l]) => (
            <li key={b} className="flex items-center gap-1.5">
              <span className="size-3 rounded-[3px]" style={{ background: `var(--score-${b})` }} /> {l}
            </li>
          ))}
          <li>– not scored</li>
        </ul>
      )}
      <figcaption className="text-xs text-muted">
        {mode === "stage"
          ? "Each cell: the furthest stage the country's documents describe in the domain, the number of distinct findings, and how the latest edition compares with earlier ones."
          : `Each cell: the domain score from rubric ${RUBRIC.id} v${RUBRIC.version}, the sum of its topic scores. A negative score marks evidence gaps in the answers to the current domain questions, not poor performance. Domains overlap, so scores are never added across a row.`}
      </figcaption>
    </figure>
  );
}
