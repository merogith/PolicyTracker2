import { AlertTriangle, Clock, Loader2 } from "lucide-react";
import { domainHue, hue } from "@/lib/colors";
import type { CardData } from "@/lib/views";

/** One chip per domain, jumping to its card: the quickest way through sixteen cards. */
export function DomainIndex({ cards, prefix }: { cards: CardData[]; prefix: string }) {
  return (
    <nav aria-label="Jump to a domain" className="sticky top-14 z-10 -mx-1 mb-4 bg-canvas/95 px-1 py-2 backdrop-blur-sm lg:top-0">
      <ul className="flex flex-wrap gap-1.5">
        {cards.map((c) => {
          const out = c.result?.output as { not_found?: boolean; findings?: unknown[] } | null | undefined;
          return (
            <li key={c.domain.id}>
              <a
                href={`#${prefix}-${c.domain.id}`}
                style={hue(domainHue(c.domain.id))}
                className="hue-band flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium text-foreground transition-colors hover:brightness-95"
              >
                <span className="hue-dot size-2 rounded-full" />
                {c.domain.label}
                {out && !out.not_found && <span className="text-muted tabular">{out.findings?.length ?? 0}</span>}
                {c.pending === "running" && <Loader2 className="size-3 animate-spin text-primary" aria-label="running" />}
                {c.pending === "queued" && <Clock className="size-3 text-muted" aria-label="queued" />}
                {c.error && !c.pending && <AlertTriangle className="size-3 text-bad" aria-label="failed" />}
                {out?.not_found && <span className="text-muted">· not found</span>}
              </a>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
