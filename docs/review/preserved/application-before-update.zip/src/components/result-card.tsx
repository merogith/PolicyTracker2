import { AlertTriangle, CheckCircle2, Clock, Loader2, SearchX } from "lucide-react";
import Link from "next/link";
import type { Citation } from "@/generated/prisma/client";
import { CONDITIONALITY, domainHue, FINDING_KINDS, hue } from "@/lib/colors";
import type { CardData } from "@/lib/views";
import { ActionButton } from "./action-button";
import { TopicChip } from "./domains-view";

type Json = Record<string, unknown>;

/** Same colours as the response-ladder chart, so a finding's stage reads the same everywhere. */
const LADDER_FILL: Record<string, string> = {
  concern: "var(--ladder-0)",
  commitment: "var(--ladder-1)",
  planned_action: "var(--ladder-2)",
  underway: "var(--ladder-3)",
  delivered: "var(--ladder-4)",
  other: "var(--ladder-other)",
};

function KindChip({ kind }: { kind: string }) {
  return (
    <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-surface-2 px-2 py-0.5 text-[11px] font-medium">
      <span className="size-2 rounded-[2px]" style={{ background: LADDER_FILL[kind] ?? LADDER_FILL.other }} aria-hidden />
      {FINDING_KINDS[kind]?.label ?? kind}
    </span>
  );
}

function Quotes({ citations, iso3, showDocument }: { citations: Citation[]; iso3: string; showDocument: boolean }) {
  if (citations.length === 0) return null;
  return (
    <ul className="mt-1.5 flex flex-col gap-1">
      {citations.map((c) => (
        <li key={c.id} className="flex items-start gap-2 text-xs leading-snug">
          <Link
            href={`/countries/${iso3}/documents/${c.documentId}?page=${c.page}&cite=${c.id}#viewer`}
            className={`inline-flex shrink-0 items-center gap-1 rounded-md px-1.5 py-0.5 font-medium tabular transition-colors ${
              c.verified ? "bg-primary-soft text-primary-ink hover:bg-primary hover:text-white" : "bg-bad-soft text-bad-ink hover:brightness-95"
            }`}
            title={c.verified ? "Open the page with this quote highlighted" : "This quote was not found on the cited page"}
          >
            {c.verified ? <CheckCircle2 className="size-3" aria-hidden /> : <AlertTriangle className="size-3" aria-hidden />}
            {showDocument ? `${c.documentId} ` : ""}p. {c.page}
            {!c.verified && <span className="sr-only">unverified</span>}
          </Link>
          <span className="line-clamp-2 text-muted" title={c.quote}>
            “{c.quote}”{c.verified && c.page !== c.citedPage && <span className="ml-1 text-[11px]">(cited as p. {c.citedPage})</span>}
          </span>
        </li>
      ))}
    </ul>
  );
}

function Answer({
  output,
  cites,
  topicsOf,
  iso3,
  country,
}: {
  output: Json;
  cites: (path: string) => Citation[];
  topicsOf: (path: string, item: Json) => string[];
  iso3: string;
  country: boolean;
}) {
  const quotes = (path: string) => <Quotes citations={cites(path)} iso3={iso3} showDocument={country} />;
  const topics = (path: string, item: Json) => {
    const ids = topicsOf(path, item);
    const unmapped = (item.unmapped_concepts as string[] | undefined) ?? [];
    if (ids.length === 0 && unmapped.length === 0) return null;
    return (
      <p className="mt-1.5 flex flex-wrap items-center gap-1">
        {ids.map((id) => (
          <TopicChip key={id} id={id} iso3={iso3} />
        ))}
        {unmapped.length > 0 && <span className="text-[11px] text-muted">no topic for: {unmapped.join("; ")}</span>}
      </p>
    );
  };
  const findings = (output.findings as Json[]) ?? [];
  return (
    <ul className="flex flex-col divide-y divide-border">
      {findings.map((it, i) => {
        const figures = (it.figures as Json[]) ?? [];
        return (
          <li key={i} className="py-2.5 first:pt-0 last:pb-0">
            <div className="flex flex-col gap-1">
              <div className="flex items-start gap-2">
                <KindChip kind={it.kind as string} />
                <p className="text-sm">{it.text as string}</p>
              </div>
              {figures.length > 0 && (
                <p className="flex flex-wrap items-center gap-1 pl-1">
                  {figures.map((n, j) => (
                    <span key={j} className="inline-flex items-center gap-1 rounded-md bg-surface-2 px-1.5 py-0.5 text-[11px] font-medium tabular">
                      <span className="font-semibold">{n.value_as_stated as string}</span>
                      {[n.unit && !String(n.value_as_stated).includes(n.unit as string) ? n.unit : null, n.period].filter(Boolean).join(" · ")}
                      {n.conditionality && n.conditionality !== "not_stated" ? <ConditionChip value={n.conditionality as string} /> : null}
                    </span>
                  ))}
                </p>
              )}
            </div>
            {topics(`findings.${i}`, it)}
            {quotes(`findings.${i}`)}
          </li>
        );
      })}
    </ul>
  );
}

function ConditionChip({ value }: { value: string }) {
  const c = CONDITIONALITY[value] ?? CONDITIONALITY.not_stated;
  return (
    <span style={hue(c.hue)} className="hue-soft rounded-full px-2 py-0.5 text-[11px] font-medium">
      {c.label}
    </span>
  );
}

export function ResultCard({
  card,
  iso3,
  rerun,
  anchor,
  showRaw = false,
}: {
  card: CardData;
  iso3: string;
  rerun: { documentId?: string; countryId?: string };
  anchor: string;
  showRaw?: boolean;
}) {
  const { domain, result, stale, retagPending, pending, error } = card;
  const country = result?.scope === "country";
  const output = (result?.output ?? null) as Json | null;
  const cites = (path: string) => (result?.citations ?? []).filter((c) => c.itemPath === path);
  const sources = (result?.sources ?? {}) as { pagesRead?: number[]; documentsWithoutAnswer?: string[] };
  // Document findings carry their own topic tags; country findings take theirs from the document findings they cite.
  const topicsOf = (path: string, item: Json) => (country ? (card.findingTopics?.[path] ?? []) : ((item.topic_ids as string[] | undefined) ?? []));
  const verified = result?.citations.filter((c) => c.verified).length ?? 0;
  const total = result?.citations.length ?? 0;

  return (
    <article id={anchor} className="panel flex scroll-mt-28 flex-col overflow-hidden" style={hue(domainHue(domain.id))}>
      <header className="hue-band flex flex-wrap items-start justify-between gap-2 border-b px-4 py-3">
        <div className="flex min-w-0 items-start gap-2.5">
          <span className="hue-dot mt-1.5 size-2.5 shrink-0 rounded-full" />
          <div className="min-w-0">
            <h3 className="text-[15px] leading-snug font-semibold">{domain.label}</h3>
            <p className="text-[11px] text-muted">
              <span className="font-mono">{domain.prefix}</span> · {domain.maxResults} pages searched · question v{result?.domainVersion ?? domain.version}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {stale && <span className="rounded-full bg-warn-soft px-2 py-0.5 text-[11px] font-medium text-warn-ink">Stale: question is now v{domain.version}</span>}
          {retagPending && !stale && <span className="rounded-full bg-warn-soft px-2 py-0.5 text-[11px] font-medium text-warn-ink" title="Tagged with an older taxonomy version; a re-tag is queued or needed">Topics being updated</span>}
          {pending === "running" && (
            <span className="inline-flex items-center gap-1 rounded-full bg-primary-soft px-2 py-0.5 text-[11px] font-medium text-primary-ink">
              <Loader2 className="size-3 animate-spin" aria-hidden /> Running
            </span>
          )}
          {pending === "queued" && (
            <span className="inline-flex items-center gap-1 rounded-full bg-surface-2 px-2 py-0.5 text-[11px] font-medium text-muted">
              <Clock className="size-3" aria-hidden /> Queued
            </span>
          )}
          {error && !pending && <span className="rounded-full bg-bad-soft px-2 py-0.5 text-[11px] font-medium text-bad-ink">Failed</span>}
          <ActionButton url="/api/results/rerun" body={{ ...rerun, domainId: domain.id }} label="Re-run" icon="rerun" variant="ghost" size="sm" title={`Ask "${domain.label}" again`} />
        </div>
      </header>

      <div className="flex flex-1 flex-col gap-3 px-4 py-3">
        {error && !pending && <p className="rounded-md bg-bad-soft px-2 py-1.5 text-xs text-bad-ink">{error}</p>}
        {!output ? (
          <p className="text-sm text-muted">{pending ? "Waiting for the analysis…" : error ? "No answer yet." : "Not run yet."}</p>
        ) : output.not_found ? (
          <div className="flex items-start gap-2 text-sm text-muted">
            <SearchX className="mt-0.5 size-4 shrink-0" aria-hidden />
            <div>
              <p className="text-foreground">Not found in the pages read.</p>
              {typeof output.note === "string" && <p className="mt-1 text-xs">{output.note}</p>}
              {Array.isArray(sources.pagesRead) && (
                <p className="mt-1 text-xs">Pages searched: {sources.pagesRead.length ? sources.pagesRead.join(", ") : "none returned"}</p>
              )}
            </div>
          </div>
        ) : (
          <>
            <Answer output={output} cites={cites} topicsOf={topicsOf} iso3={iso3} country={country} />
            {typeof output.note === "string" && output.note && <p className="text-xs text-muted">Note: {output.note}</p>}
          </>
        )}

        {country && output && !output.not_found && (
          <div className="flex flex-col gap-3 rounded-lg bg-surface-2 p-3">
            {((output.by_document as Json[]) ?? []).length > 0 && (
              <div>
                <h4 className="text-xs font-semibold">By document</h4>
                <ul className="mt-1 flex flex-col gap-1">
                  {(output.by_document as Json[]).map((b, i) => (
                    <li key={i} className="text-xs leading-snug">
                      <span className="font-mono font-medium">{b.document_id as string}</span> {b.summary as string}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {((output.changes_between_editions as Json[]) ?? []).length > 0 && (
              <div>
                <h4 className="text-xs font-semibold">Changes between editions</h4>
                <ul className="mt-1 flex flex-col gap-1">
                  {(output.changes_between_editions as Json[]).map((c, i) => (
                    <li key={i} className="text-xs leading-snug">
                      {c.text as string} <span className="font-mono text-muted">({(c.document_ids as string[]).join(", ")})</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {(sources.documentsWithoutAnswer ?? []).length > 0 && (
              <p className="text-xs text-warn-ink">No document answer yet for: {sources.documentsWithoutAnswer!.join(", ")}</p>
            )}
          </div>
        )}
      </div>

      {result && (
        <footer className="flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-border px-4 py-2 text-[11px] text-muted">
          <span className={`inline-flex items-center gap-1 ${total && verified < total ? "text-bad-ink" : "text-ok-ink"}`}>
            {total && verified < total ? <AlertTriangle className="size-3" aria-hidden /> : <CheckCircle2 className="size-3" aria-hidden />}
            {verified}/{total} quotes verified
          </span>
          <span>{result.model}</span>
          <span className="tabular">${result.costUsd.toFixed(4)}</span>
          {result.finishedAt && <span className="tabular">{result.finishedAt.toISOString().slice(0, 16).replace("T", " ")}</span>}
        </footer>
      )}
      {showRaw && result && (
        <details className="border-t border-border px-4 py-2 text-xs">
          <summary className="cursor-pointer text-muted hover:text-foreground">Raw JSON</summary>
          <pre className="mt-2 max-h-96 overflow-auto rounded-md bg-surface-2 p-2">{JSON.stringify(result.output, null, 2)}</pre>
        </details>
      )}
    </article>
  );
}
