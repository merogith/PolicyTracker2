import { AlertTriangle, ArrowLeft, CheckCircle2, Info } from "lucide-react";
import Link from "next/link";
import { domainHue, FINDING_KINDS, hue } from "@/lib/colors";
import { loadTaxonomyCached } from "@/lib/taxonomy";
import { STAGE_KINDS, type CountryTopics, type MergedItem, type StageCounts } from "@/lib/topics";
import { BUCKETS, bucket } from "./charts/coverage-heatmap";
import { KindDot } from "./charts/kind";
import { StageChart } from "./charts/ladder-chart";
import { ScoreChip, StatusSwatch, statusLabel, TrendBadge, trendLabel } from "./charts/stage";
import { ChartTooltips } from "./charts/tooltip";
import { Section } from "./section";
import { plural } from "@/lib/plural";

const STAGE_FILL = ["var(--ladder-0)", "var(--ladder-1)", "var(--ladder-2)", "var(--ladder-3)", "var(--ladder-4)"];
const OTHER_LABEL = "Other (no stage)";

function stageRow(c: StageCounts) {
  return [...c.byStage, c.unstaged];
}

function PrefixMark({ prefix }: { prefix: string }) {
  return <span className="w-9 shrink-0 rounded bg-surface-2 px-1 py-0.5 text-center font-mono text-[10px] font-semibold text-muted">{prefix}</span>;
}

function OverlapNote() {
  return (
    <p className="flex items-start gap-2 rounded-lg bg-surface-2 px-3 py-2 text-xs text-muted">
      <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden />
      Topics come from fresh-start/config/taxonomy.json. A finding tagged with topics in two domains appears in both, so domain counts overlap and are never added up. Findings that share a quote count once.
    </p>
  );
}

export function DomainsView({
  data,
  iso3,
  domainId,
  topicId,
  view,
  filter,
}: {
  data: CountryTopics;
  iso3: string;
  domainId?: string;
  topicId?: string;
  view?: string;
  filter?: string;
}) {
  const base = `/countries/${iso3}?tab=domains`;
  if (!data.ready) {
    return <p className="text-sm text-muted">The combined summaries are not ready yet. Topic and domain views fill in as they finish.</p>;
  }
  const outdated =
    data.outdated > 0 ? (
      <p className="flex items-start gap-2 rounded-lg bg-warn-soft px-3 py-2 text-xs text-warn-ink">
        <AlertTriangle className="mt-0.5 size-3.5 shrink-0" aria-hidden />
        {plural(data.outdated, "answer")} {data.outdated === 1 ? "was" : "were"} made with an earlier prompt version. Re-run the documents (Documents tab) to refresh them.
      </p>
    ) : null;

  const t = topicId ? data.tax.topic(topicId) : undefined;
  if (t) return <TopicDetail data={data} iso3={iso3} topicId={t.id} base={base} />;
  const d = domainId ? data.tax.domain(domainId) : undefined;
  if (d) return <DomainDetail data={data} domainId={d.id} base={base} outdated={outdated} />;

  const seg = (on: boolean) =>
    `rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${on ? "bg-surface text-primary-ink shadow-card" : "text-muted hover:text-foreground"}`;
  return (
    <div className="flex flex-col gap-6">
      <nav aria-label="Domains view" className="flex w-fit gap-1 rounded-lg bg-surface-2 p-1">
        <Link href={base} className={seg(view !== "topics")} aria-current={view !== "topics" ? "page" : undefined}>
          Domain profiles
        </Link>
        <Link href={`${base}&view=topics`} className={seg(view === "topics")} aria-current={view === "topics" ? "page" : undefined}>
          All 64 topics
        </Link>
      </nav>
      {outdated}
      {view === "topics" ? (
        <TopicStatusTable data={data} base={base} filter={filter} />
      ) : (
        <>
          <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_20rem]">
            <DomainProfiles data={data} iso3={iso3} base={base} />
            <div className="xl:sticky xl:top-6">
              <ScoreReading data={data} />
            </div>
          </div>
          <Section title="Domains per document" description="How many items each document's own answers tag with a topic in the domain.">
            <DomainGrid data={data} iso3={iso3} base={base} />
          </Section>
          {(data.untagged.length > 0 || data.unmapped.length > 0) && (
            <Section title="Not covered by a topic" description="Items no topic fitted. They stay in the answers; this list shows where the taxonomy may need a new topic.">
              {data.unmapped.length > 0 && (
                <ul className="flex flex-wrap gap-1.5">
                  {data.unmapped.slice(0, 60).map((u) => (
                    <li key={u.concept} className="rounded-full bg-surface-2 px-2.5 py-1 text-xs" title={u.documents.join(", ")}>
                      {u.concept} <span className="font-mono text-muted">{u.documents.join(", ")}</span>
                    </li>
                  ))}
                </ul>
              )}
              {data.untagged.length > 0 && <MergedList items={data.untagged.slice(0, 20)} iso3={iso3} />}
            </Section>
          )}
        </>
      )}
    </div>
  );
}

/** How the scores are made, quoted from the rubric file. */
export function ScoreReading({ data }: { data: Pick<CountryTopics, "rubric"> }) {
  return (
    <aside className="panel flex flex-col gap-3 p-5 text-sm">
      <h2 className="text-base font-semibold">Reading the score</h2>
      {data.rubric.reading.map((r) => (
        <p key={r} className="text-muted">
          {r}
        </p>
      ))}
      <p className="text-muted">{data.rubric.domain_rule}</p>
      <p className="border-t border-border pt-3 text-xs text-muted">
        Rubric <span className="font-mono">{data.rubric.id}</span> v{data.rubric.version} ({data.rubric.status}), in config/scoring/rubric.json. Colours and arrows show stages, not scores.
      </p>
    </aside>
  );
}

/** One card per domain: score, furthest stage, latest-edition trend, findings by stage and the findings that went furthest. */
function DomainProfiles({ data, iso3, base }: { data: CountryTopics; iso3: string; base: string }) {
  const max = Math.max(1, ...data.domains.map((d) => d.counts.total));
  return (
    <section className="flex flex-col gap-3" aria-label="Domain profiles">
      <ul className="grid gap-3 lg:grid-cols-2">
        {data.domains.map((d) => {
          const counts = stageRow(d.counts);
          return (
            <li key={d.domain.id} className="panel flex flex-col gap-3 p-4">
              <div className="flex items-start justify-between gap-3">
                <Link href={`${base}&domain=${d.domain.id}`} className="flex min-w-0 items-center gap-2 hover:underline">
                  <PrefixMark prefix={d.domain.prefix} />
                  <span className="truncate font-semibold">{d.domain.label}</span>
                </Link>
                <span className="flex shrink-0 items-center gap-2">
                  <TrendBadge trend={d.summary.trend} compact />
                  <ScoreChip score={d.score.scored ? d.score : null} size="md" />
                </span>
              </div>
              <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted">
                <span className="inline-flex items-center gap-1.5">
                  <StatusSwatch status={d.summary.status} /> {statusLabel(d.summary.status)}
                </span>
                <span>
                  {d.topicsTouched}/{d.topicCount} topics
                </span>
                <span className="tabular">{plural(d.counts.total, "finding")}</span>
                <span>{trendLabel(d.summary.trend)}</span>
              </p>
              <div className="flex h-2.5 gap-[2px]" style={{ width: `${Math.max(2, (100 * d.counts.total) / max)}%` }} aria-hidden>
                {counts.map((n, i) =>
                  n > 0 ? <span key={i} className="h-full first:rounded-l-[3px] last:rounded-r-[3px]" style={{ flexGrow: n, flexBasis: 0, background: i < 5 ? STAGE_FILL[i] : "var(--ladder-other)" }} /> : null,
                )}
                {d.counts.total === 0 && <span className="h-full w-full rounded-[3px] bg-surface-2" />}
              </div>
              {d.highlights.length > 0 && (
                <ul className="flex flex-col gap-1.5">
                  {d.highlights.map((m, i) => {
                    const u = m.units[0];
                    const c = u.citations[0];
                    return (
                      <li key={i} className="flex items-start gap-2 text-xs leading-snug">
                        <span className="mt-0.5 size-2 shrink-0 rounded-[2px]" style={{ background: m.stage !== null ? STAGE_FILL[m.stage] : "var(--ladder-other)" }} aria-hidden />
                        <span className="line-clamp-2 flex-1">{u.text}</span>
                        {c && (
                          <Link href={`/countries/${iso3}/documents/${c.documentId}?page=${c.page}&cite=${c.id}#viewer`} className="shrink-0 font-mono text-[11px] text-primary-ink hover:underline">
                            {c.documentId} p.{c.page}
                          </Link>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </li>
          );
        })}
      </ul>
      <details className="text-xs">
        <summary className="cursor-pointer text-muted hover:text-foreground">Show as table</summary>
        <div className="overflow-x-auto">
          <table className="mt-2 w-full text-left">
            <thead className="text-muted">
              <tr>
                <th className="py-1 pr-3 font-medium">Domain</th>
                {[...STAGE_KINDS.map((k) => FINDING_KINDS[k].label), "No stage"].map((l) => (
                  <th key={l} className="py-1 pr-3 text-right font-medium">
                    {l}
                  </th>
                ))}
                <th className="py-1 pr-3 font-medium">Latest edition</th>
                <th className="py-1 font-medium">Score</th>
              </tr>
            </thead>
            <tbody>
              {data.domains.map((d) => (
                <tr key={d.domain.id} className="border-t border-border">
                  <td className="py-1 pr-3">{d.domain.label}</td>
                  {stageRow(d.counts).map((n, i) => (
                    <td key={i} className="py-1 pr-3 text-right tabular">
                      {n}
                    </td>
                  ))}
                  <td className="py-1 pr-3">{trendLabel(d.summary.trend)}</td>
                  <td className="py-1 tabular">{d.score.scored ? `${d.score.sum} / ${d.score.topics}` : "not scored"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
      <OverlapNote />
    </section>
  );
}

/** Status of every topic in the taxonomy, grouped by home domain. */
function TopicStatusTable({ data, base, filter }: { data: CountryTopics; base: string; filter?: string }) {
  const rows = data.topics.filter((t) => (filter === "found" ? t.items.length > 0 : filter === "none" ? t.items.length === 0 : true));
  const found = data.topics.filter((t) => t.items.length > 0).length;
  const pill = (on: boolean) => `rounded-full border px-3 py-1 text-xs font-medium ${on ? "border-primary bg-primary text-white" : "border-border bg-surface text-muted hover:text-foreground"}`;
  return (
    <Section
      title="Topic status"
      description={`${found} of ${data.topics.length} topics have findings in this country's combined summaries. Status is the furthest stage documented; the score follows the rubric.`}
      actions={
        <div className="flex gap-1.5">
          <Link href={`${base}&view=topics`} className={pill(!filter)}>
            All
          </Link>
          <Link href={`${base}&view=topics&filter=found`} className={pill(filter === "found")}>
            With findings
          </Link>
          <Link href={`${base}&view=topics&filter=none`} className={pill(filter === "none")}>
            No findings
          </Link>
        </div>
      }
    >
      <div className="overflow-x-auto">
        <table className="w-full min-w-[46rem] text-sm">
          <thead className="text-left text-xs text-muted">
            <tr className="border-b border-border">
              <th className="py-2 pr-4 font-medium">Topic</th>
              <th className="py-2 pr-4 font-medium">Status</th>
              <th className="py-2 pr-4 font-medium">Latest edition</th>
              <th className="py-2 pr-4 text-right font-medium">Findings</th>
              <th className="py-2 pr-4 font-medium">Documents</th>
              <th className="py-2 font-medium">Score</th>
            </tr>
          </thead>
          {data.tax.domains.map((dom) => {
            const inDomain = rows.filter((t) => t.topic.placements[0].domain === dom.id);
            if (inDomain.length === 0) return null;
            return (
              <tbody key={dom.id}>
                <tr>
                  <th colSpan={6} className="pt-4 pb-1 text-left text-xs font-semibold">
                    <Link href={`${base}&domain=${dom.id}`} className="inline-flex items-center gap-2 hover:underline">
                      <PrefixMark prefix={dom.prefix} /> {dom.label}
                    </Link>
                  </th>
                </tr>
                {inDomain.map((t) => (
                  <tr key={t.topic.id} className="border-b border-border align-top last:border-0">
                    <td className="py-2 pr-4">
                      <Link href={`${base}&topic=${t.topic.id}`} className="hover:underline">
                        <span className="font-mono text-xs font-semibold">{t.topic.id}</span> {t.topic.label}
                      </Link>
                    </td>
                    <td className="py-2 pr-4">
                      <span className="inline-flex items-center gap-1.5 text-xs">
                        <StatusSwatch status={t.summary.status} /> {statusLabel(t.summary.status)}
                      </span>
                    </td>
                    <td className="py-2 pr-4">
                      <TrendBadge trend={t.summary.trend} />
                    </td>
                    <td className="py-2 pr-4 text-right tabular">{t.items.length}</td>
                    <td className="py-2 pr-4 font-mono text-xs">{t.summary.documents.join(", ") || "–"}</td>
                    <td className="py-2">
                      <ScoreChip score={t.score} />
                    </td>
                  </tr>
                ))}
              </tbody>
            );
          })}
        </table>
      </div>
    </Section>
  );
}

function DomainGrid({ data, iso3, base }: { data: CountryTopics; iso3: string; base: string }) {
  if (data.documents.length === 0) return <p className="text-sm text-muted">No documents yet.</p>;
  return (
    <figure className="flex flex-col gap-3">
      <ul className="flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-muted" aria-label="Legend">
        <li>Items tagged:</li>
        {BUCKETS.map((b, i) => (
          <li key={b.label} className="flex items-center gap-1">
            <span className="size-3 rounded-[3px]" style={{ background: `var(--heat-${i + 1})` }} />
            {b.label}
          </li>
        ))}
        <li>· none</li>
      </ul>
      <ChartTooltips className="overflow-x-auto">
        <table className="w-full border-separate border-spacing-[2px] text-xs">
          <thead>
            <tr>
              <th className="w-56 text-left font-medium text-muted">Domain</th>
              {data.documents.map((d) => (
                <th key={d.id} className="min-w-24 px-1 pb-1 text-center font-medium">
                  <Link href={`/countries/${iso3}?tab=${d.id}`} className="inline-flex flex-col items-center gap-0.5 hover:underline">
                    <span className="flex items-center gap-1.5 font-mono text-[11px]">
                      <KindDot kind={d.kind} /> {d.id}
                    </span>
                    <span className="font-normal text-muted">{d.editionDate.slice(0, 7)}</span>
                  </Link>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.tax.domains.map((dom) => (
              <tr key={dom.id}>
                <th scope="row" className="pr-2 text-left font-normal">
                  <Link href={`${base}&domain=${dom.id}`} className="flex items-center gap-2 text-[13px] hover:underline">
                    <PrefixMark prefix={dom.prefix} />
                    <span className="truncate">{dom.label}</span>
                  </Link>
                </th>
                {data.docDomains.map((dd) => {
                  const n = dd.perDomain.get(dom.id) ?? 0;
                  const b = n ? bucket(n) : 0;
                  return (
                    <td key={dd.document.id} className="p-0">
                      <span
                        tabIndex={0}
                        data-tip-value={n ? `${n} item${n === 1 ? "" : "s"}` : "None"}
                        data-tip-label={`${dom.label} · ${dd.document.id}`}
                        aria-label={`${dom.label} in ${dd.document.id}: ${n} items`}
                        className="flex h-7 items-center justify-center rounded-[4px] font-semibold tabular"
                        style={b ? { background: `var(--heat-${b})`, color: `var(--heat-ink-${b})` } : { background: "var(--surface-2)" }}
                      >
                        {n || <span className="font-normal text-muted">·</span>}
                      </span>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </ChartTooltips>
      <figcaption className="text-xs text-muted">Counts come from each document&apos;s own answers, before they are combined. An item in two domains counts in both.</figcaption>
    </figure>
  );
}

function DomainDetail({ data, domainId, base, outdated }: { data: CountryTopics; domainId: string; base: string; outdated: React.ReactNode }) {
  const d = data.tax.domain(domainId)!;
  const summary = data.domains.find((x) => x.domain.id === d.id);
  const topics = data.tax.topicsOfDomain(d.id);
  const groups = d.groups.map((g) => ({ group: g, topics: topics.filter((t) => data.tax.groupOf(t.id, d.id)?.id === g.id) })).filter((g) => g.topics.length > 0);
  // One scale for every group of the domain, so bars compare across groups.
  const scaleMax = Math.max(1, ...topics.map((t) => data.topicCounts(t.id).total));
  return (
    <div className="flex flex-col gap-5">
      <Link href={base} className="flex w-fit items-center gap-1.5 text-sm text-primary-ink hover:underline">
        <ArrowLeft className="size-3.5" aria-hidden /> All domains
      </Link>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <PrefixMark prefix={d.prefix} /> {d.label}
          </h2>
          <p className="mt-1 max-w-prose text-sm text-muted">{d.definition}</p>
        </div>
        {summary && (
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="inline-flex items-center gap-1.5">
              <StatusSwatch status={summary.summary.status} /> {statusLabel(summary.summary.status)}
            </span>
            <TrendBadge trend={summary.summary.trend} />
            <ScoreChip score={summary.score.scored ? summary.score : null} size="md" />
          </div>
        )}
      </div>
      {outdated}
      {groups.map(({ group, topics: ts }) => (
        <Section key={group.id} title={group.label}>
          <StageChart
            otherLabel={OTHER_LABEL}
            wideLabels
            scaleMax={scaleMax}
            rows={ts.map((t) => ({
              id: t.id,
              label: `${t.id} ${t.label}${t.placements[0].domain !== d.id ? ` (home: ${data.tax.domain(t.placements[0].domain)?.label})` : ""}`,
              href: `${base}&topic=${t.id}`,
              counts: stageRow(data.topicCounts(t.id)),
              ready: true,
              empty: "nothing tagged",
            }))}
            caption="Select a topic to read its findings and their quotes."
          />
        </Section>
      ))}
      <OverlapNote />
    </div>
  );
}

function TopicDetail({ data, iso3, topicId, base }: { data: CountryTopics; iso3: string; topicId: string; base: string }) {
  const t = data.tax.topic(topicId)!;
  const home = data.tax.domain(t.placements[0].domain)!;
  const items = [...data.topicItems(t.id)].sort((a, b) => (b.stage ?? -1) - (a.stage ?? -1));
  const c = data.topicCounts(t.id);
  const ts = data.topicSummary(t.id);
  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap gap-4 text-sm">
        <Link href={base} className="flex items-center gap-1.5 text-primary-ink hover:underline">
          <ArrowLeft className="size-3.5" aria-hidden /> All domains
        </Link>
        <Link href={`${base}&domain=${home.id}`} className="text-primary-ink hover:underline">
          {home.label}
        </Link>
      </div>
      <div className="flex flex-col gap-2">
        <h2 className="text-lg font-semibold">
          <span className="font-mono text-muted">{t.id}</span> {t.label}
        </h2>
        {ts && (
          <p className="flex flex-wrap items-center gap-3 text-xs">
            <span className="inline-flex items-center gap-1.5">
              <StatusSwatch status={ts.summary.status} /> {statusLabel(ts.summary.status)}
            </span>
            <TrendBadge trend={ts.summary.trend} />
            <ScoreChip score={ts.score} size="md" />
          </p>
        )}
        <p className="max-w-prose text-sm text-muted">{t.definition}</p>
        <p className="flex flex-wrap gap-1.5 text-xs">
          {t.placements.map((p) => (
            <Link key={p.domain} href={`${base}&domain=${p.domain}`} className="rounded-full bg-surface-2 px-2 py-0.5 hover:underline">
              {data.tax.domain(p.domain)?.label} › {data.tax.groupOf(t.id, p.domain)?.label}
            </Link>
          ))}
        </p>
        {t.routing.length > 0 && <p className="text-xs text-muted">Neighbours: {t.routing.map((r) => `for ${r.when} see ${r.use}`).join("; ")}</p>}
      </div>
      <Section
        title={`${c.total} item${c.total === 1 ? "" : "s"} in the combined summaries`}
        description={
          <span className="flex flex-wrap gap-x-3 gap-y-1">
            {STAGE_KINDS.map((k, i) => (
              <span key={k} className="inline-flex items-center gap-1.5">
                <span className="size-2.5 rounded-[3px]" style={{ background: STAGE_FILL[i] }} />
                {FINDING_KINDS[k].label} {c.byStage[i]}
              </span>
            ))}
            <span>{OTHER_LABEL} {c.unstaged}</span>
          </span>
        }
      >
        {items.length === 0 ? <p className="text-sm text-muted">Nothing in this country&apos;s documents is tagged with this topic.</p> : <MergedList items={items} iso3={iso3} />}
      </Section>
    </div>
  );
}

function MergedList({ items, iso3 }: { items: MergedItem[]; iso3: string }) {
  return (
    <ul className="flex flex-col divide-y divide-border">
      {items.map((m, i) => (
        <li key={i} className="flex flex-col gap-2 py-3 first:pt-0 last:pb-0">
          <div className="flex flex-wrap items-center gap-1.5">
            {m.stage !== null ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-surface-2 px-2 py-0.5 text-[11px] font-medium">
                <span className="size-2 rounded-[2px]" style={{ background: STAGE_FILL[m.stage] }} />
                {FINDING_KINDS[STAGE_KINDS[m.stage]].label}
              </span>
            ) : (
              <span className="rounded-full bg-surface-2 px-2 py-0.5 text-[11px] font-medium text-muted">No stage</span>
            )}
            {m.units.length > 1 && <span className="text-[11px] text-muted">merged from {m.units.length} answers that share a quote</span>}
            <span className="font-mono text-[11px] text-muted">{m.documents.join(", ")}</span>
          </div>
          {m.units.map((u, j) => (
            <div key={j} className="flex flex-col gap-1">
              <p className="text-sm">
                <span className="mr-1.5 inline-flex items-center gap-1 text-[11px] font-medium text-muted" style={hue(domainHue(u.domainId))}>
                  <span className="hue-dot size-2 rounded-full" /> {u.domainLabel}
                </span>
                {u.text}
              </p>
              <ul className="flex flex-col gap-1">
                {u.citations.map((c) => (
                  <li key={c.id} className="flex items-start gap-2 text-xs leading-snug">
                    <Link
                      href={`/countries/${iso3}/documents/${c.documentId}?page=${c.page}&cite=${c.id}#viewer`}
                      className={`inline-flex shrink-0 items-center gap-1 rounded-md px-1.5 py-0.5 font-medium tabular ${c.verified ? "bg-primary-soft text-primary-ink" : "bg-bad-soft text-bad-ink"}`}
                    >
                      {c.verified ? <CheckCircle2 className="size-3" aria-hidden /> : <AlertTriangle className="size-3" aria-hidden />}
                      {c.documentId} p. {c.page}
                    </Link>
                    <span className="line-clamp-2 text-muted" title={c.quote}>
                      “{c.quote}”
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          {m.topics.length > 1 && (
            <p className="flex flex-wrap gap-1">
              {m.topics.map((id) => (
                <TopicChip key={id} id={id} iso3={iso3} />
              ))}
            </p>
          )}
        </li>
      ))}
    </ul>
  );
}

export async function TopicChip({ id, iso3 }: { id: string; iso3: string }) {
  const t = (await loadTaxonomyCached()).topic(id);
  return (
    <Link
      href={`/countries/${iso3}?tab=domains&topic=${id}`}
      title={t ? `${t.label}: ${t.definition}` : id}
      className="inline-flex items-center gap-1 rounded-md border border-border bg-surface px-1.5 py-0.5 text-[11px] hover:border-primary hover:text-primary-ink"
    >
      <span className="font-mono font-semibold">{id}</span>
      {t && <span className="max-w-40 truncate text-muted">{t.label}</span>}
    </Link>
  );
}
