import Link from "next/link";

export interface TabItem {
  id: string;
  href: string;
  label: React.ReactNode;
  hint?: React.ReactNode;
}

/** Link tabs: each tab is a URL, so tabs survive refreshes and can be shared. */
export function Tabs({ items, active, label }: { items: TabItem[]; active: string; label: string }) {
  return (
    <nav aria-label={label} className="-mx-1 mb-5 overflow-x-auto border-b border-border">
      <ul className="flex min-w-max gap-1 px-1">
        {items.map((t) => {
          const on = t.id === active;
          return (
            <li key={t.id}>
              <Link
                href={t.href}
                aria-current={on ? "page" : undefined}
                className={`-mb-px flex items-center gap-2 border-b-2 px-3 pt-2 pb-2.5 text-sm font-medium transition-colors ${
                  on ? "border-primary text-primary-ink" : "border-transparent text-muted hover:border-border-strong hover:text-foreground"
                }`}
              >
                {t.label}
                {t.hint}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
