# Policy Tracker

A dashboard for national climate and disaster-risk policy documents. Create a country, upload its PDFs, and every document is asked one question per domain of the taxonomy (16 domains, 64 topics, seeded from `fresh-start/config/taxonomy.json`). Each answer lists findings with their response stage, the figures they state and quotes with page numbers, checked automatically against the page text. Each domain also gets a combined summary across the country's documents, and each country gets an overview of charts.

Every finding is tagged with topic IDs; domains come from the topics' placements. The Domains & topics tab of a country shows findings by domain and topic, merging findings that cite the same quote. A topic can sit in two domains, so domain counts overlap and are never added up.

Domains and topics are edited on the Domains & topics page (sidebar). Each edit shows what it will re-run before you save:

- A domain's label or definition, or a topic's label or placement, changes the question of the domains involved: those domains get a new question version and are asked again of every document. All other stored answers are re-tagged.
- A topic's definition or routing hints only change tagging: stored answers are re-tagged with the cheaper model, without reading pages again.
- Topic IDs are never reused. Moving a topic to another home domain gives it a new ID and keeps the old one as a legacy ID. Every edit raises the taxonomy revision (`0.1.0-draft+r3`), and each answer records the revision it was tagged with.

Each country's Overview opens with a domain dashboard: a tile per domain, coloured by the furthest response stage, with an arrow comparing the latest edition with earlier ones. The Countries page shows every country against the domains. Scores are a separate layer: `config/scoring/rubric.json` (versioned) turns each topic's furthest stage into points (a topic with no findings scores -1), and a domain score sums its topics. They are shown next to the stages and never replace them.

Design: [docs/PLAN.md](docs/PLAN.md). Build steps and acceptance checks: [docs/IMPLEMENTATION.md](docs/IMPLEMENTATION.md).

## Run it

Needs Node 20 or later (`.nvmrc` pins 22).

```bash
npm install
cp .env.example .env        # then set OPENAI_API_KEY, or OPENAI_FAKE=1 to try it without a key
npm run db:migrate
npm run db:seed             # the taxonomy (domains and topics)
npm run dev                 # the dashboard, http://localhost:3000
npm run worker              # in a second terminal: reads, indexes and analyses documents
```

With `OPENAI_FAKE=1` the whole pipeline runs against a local stand-in for OpenAI: answers are made up from the page text, so they exercise the app but say nothing about the documents. The sidebar shows "Demo mode" while it is on.

To make two synthetic test PDFs: `npx tsx scripts/make-sample-pdfs.ts data/samples`.

## Checks

```bash
npm run check               # typecheck, lint, unit tests, and every stored result validated against its schema
npx tsx scripts/check-results.ts --country KAZ --show water
npx tsx scripts/scenario.ts --base http://localhost:3000 --iso3 KAZ --name Kazakhstan \
  --doc "path/ndc3.pdf|NDC|2025-11-26|NDC 3.0" --doc "path/nap.pdf|NAP|2024-01-01|National Adaptation Plan"
```

`scenario.ts` runs the acceptance scenario of IMPLEMENTATION.md Part 9 against a running app and worker on a fresh database, and prints PASS or FAIL for each step. Since domains replaced analysis keys, its steps 5 and 6 add a domain with a topic (only that domain is asked; other answers are re-tagged) and edit a topic definition (re-tags only).

## Where things are

| Path | What |
|---|---|
| `src/lib/openai.ts` | The only place that calls OpenAI; the verified API shapes are noted at the top. `openai-fake.ts` is the stand-in. |
| `src/lib/ingest.ts` | PDF upload, page extraction, one text file per page in the country's vector store |
| `src/lib/analysis/` | Schemas, prompts (`prompt.ts`), the per-document run, citation checks, the country synthesis, the re-tag pass, prices |
| `src/lib/taxonomy.ts`, `src/lib/taxonomy-edit.ts`, `src/lib/topics.ts` | Reads the taxonomy from the database; edits it and plans what re-runs; builds the domain and topic views |
| `config/scoring/rubric.json`, `src/lib/scoring.ts` | The scoring rubric and how it is applied |
| `src/worker/` | The job loop and its handlers |
| `src/app/`, `src/components/` | Pages, API routes, cards and charts |
| `prisma/` | Schema, migrations, seed |
