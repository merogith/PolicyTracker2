import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Pages read live job and result state from the database on every request,
  // so the app uses plain dynamic rendering rather than Cache Components.
  serverExternalPackages: ["better-sqlite3", "@prisma/adapter-better-sqlite3", "pdfjs-dist"],
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
